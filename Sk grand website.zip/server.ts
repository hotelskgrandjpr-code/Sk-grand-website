import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { Resend } from "resend";
import dotenv from "dotenv";
import reservationHandler from "./api/reservation.ts";

dotenv.config();

// Initialize Firebase Admin (safely handle if credentials not yet configured)
let firebaseInitialized = false;
try {
  if (!getApps().length) {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      initializeApp({
        credential: cert(serviceAccount)
      });
      firebaseInitialized = true;
    } else {
      // Try default application credentials
      initializeApp();
      firebaseInitialized = true;
    }
  } else {
    firebaseInitialized = true;
  }
} catch (e) {
  console.warn("Firebase Admin initialization warning:", e);
}

const db = firebaseInitialized ? getFirestore() : null;

// Initialize Resend
const resendApiKey = process.env.RESEND_API_KEY;
const resend = resendApiKey ? new Resend(resendApiKey) : null;
const notificationEmail = process.env.BOOKING_NOTIFICATION_EMAIL || "info@hotelskgrand.com";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// API Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", firebase: firebaseInitialized, resened: !!resend });
});

// Secure Reservation Endpoint
app.all("/api/reservation", async (req, res) => {
  return reservationHandler(req, res);
});

// Backward-compatible Bookings Endpoint
app.all("/api/bookings", async (req, res) => {
  return reservationHandler(req, res);
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  if (!process.env.VERCEL) {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on port ${PORT}`);
    });
  }
}

if (!process.env.VERCEL) {
  startServer();
} else {
  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
}

export default app;
