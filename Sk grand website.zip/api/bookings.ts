import reservationHandler from "./reservation.ts";

export default async function handler(req: any, res: any) {
  return reservationHandler(req, res);
}
