import { Resend } from 'resend';

// Simple in-memory rate limiting & duplicate prevention for serverless/Express environment
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const recentSubmissions = new Map<string, { bookingId: string; timestamp: number }>();

// Periodic cleanup of rate limit caches (every 5 minutes)
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of rateLimitMap.entries()) {
    if (now > val.resetTime) rateLimitMap.delete(key);
  }
  for (const [key, val] of recentSubmissions.entries()) {
    if (now - val.timestamp > 120000) recentSubmissions.delete(key);
  }
}, 300000);

// HTML escaping helper to prevent HTML injection in email clients
function escapeHtml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export interface ReservationPayload {
  fullName?: string;
  name?: string;
  guestName?: string;
  phoneNumber?: string;
  phone?: string;
  email?: string;
  checkInDate?: string;
  checkIn?: string;
  checkOutDate?: string;
  checkOut?: string;
  numberOfGuests?: string | number;
  guests?: string | number;
  adults?: string | number;
  roomType?: string;
  specialRequest?: string;
  specialRequests?: string;
  category?: 'room' | 'banquet' | string;
}

export default async function handler(req: any, res: any) {
  // CORS configuration
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,POST');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      message: 'Method not allowed. Please use POST.'
    });
  }

  // 1. Rate Limiting Check (max 5 requests per 5 minutes per IP)
  const clientIp = (
    req.headers['x-forwarded-for'] ||
    req.headers['x-real-ip'] ||
    req.socket?.remoteAddress ||
    '127.0.0.1'
  ).toString().split(',')[0].trim();

  const now = Date.now();
  const rateRecord = rateLimitMap.get(clientIp);

  if (rateRecord && now < rateRecord.resetTime) {
    if (rateRecord.count >= 5) {
      return res.status(429).json({
        success: false,
        message: 'Too many reservation requests. Please wait a few minutes before trying again.'
      });
    }
    rateRecord.count += 1;
  } else {
    rateLimitMap.set(clientIp, { count: 1, resetTime: now + 5 * 60 * 1000 });
  }

  try {
    // 2. Parse & Extract Payload
    let body: ReservationPayload = req.body || {};
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        return res.status(400).json({
          success: false,
          message: 'Malformed request body. Valid JSON is required.'
        });
      }
    }

    const fullName = (body.fullName || body.name || body.guestName || '').toString().trim();
    const phoneNumber = (body.phoneNumber || body.phone || '').toString().trim();
    const email = (body.email || '').toString().trim().toLowerCase();
    const checkInDate = (body.checkInDate || body.checkIn || '').toString().trim();
    const checkOutDate = (body.checkOutDate || body.checkOut || '').toString().trim();
    const numberOfGuests = (body.numberOfGuests || body.guests || body.adults || '2 Guests').toString().trim();
    const roomType = (body.roomType || '').toString().trim();
    const specialRequest = (body.specialRequest || body.specialRequests || '').toString().trim();
    const category = body.category || 'room';

    // 3. Strict Server-side Validation
    if (!fullName || fullName.length < 2 || fullName.length > 100) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid full name (2 to 100 characters).'
      });
    }

    // Phone validation: 6-25 chars, valid phone chars
    const phoneRegex = /^[+]?[\d\s\-().]{6,25}$/;
    if (!phoneNumber || !phoneRegex.test(phoneNumber)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid contact phone number.'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    if (!email || !emailRegex.test(email) || email.length > 100) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address.'
      });
    }

    // Date validation
    if (!checkInDate) {
      return res.status(400).json({
        success: false,
        message: 'Please select a valid check-in date.'
      });
    }

    const parsedCheckIn = new Date(checkInDate);
    if (isNaN(parsedCheckIn.getTime())) {
      return res.status(400).json({
        success: false,
        message: 'Check-in date is not a valid calendar date.'
      });
    }

    if (category === 'room') {
      if (!checkOutDate) {
        return res.status(400).json({
          success: false,
          message: 'Please select a valid check-out date.'
        });
      }
      const parsedCheckOut = new Date(checkOutDate);
      if (isNaN(parsedCheckOut.getTime())) {
        return res.status(400).json({
          success: false,
          message: 'Check-out date is not a valid calendar date.'
        });
      }
      if (parsedCheckOut < parsedCheckIn) {
        return res.status(400).json({
          success: false,
          message: 'Check-out date must be the same as or after check-in date.'
        });
      }
    }

    // Room Type validation
    if (!roomType || roomType.length > 100) {
      return res.status(400).json({
        success: false,
        message: 'Please select a valid room or accommodation type.'
      });
    }

    // Special Request length guard
    if (specialRequest.length > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Special request note cannot exceed 1000 characters.'
      });
    }

    // 4. Duplicate Submission Guard (prevent duplicate submission spam within 60s)
    const submissionKey = `${email}|${checkInDate}|${roomType}|${fullName}`.toLowerCase();
    const existingSubmission = recentSubmissions.get(submissionKey);
    if (existingSubmission && now - existingSubmission.timestamp < 60000) {
      return res.status(200).json({
        success: true,
        message: 'Reservation request sent successfully.',
        bookingId: existingSubmission.bookingId
      });
    }

    // 5. Generate Reference ID (SKG-YYYYMMDD-XXX)
    const dateObj = new Date();
    const yyyy = dateObj.getFullYear();
    const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
    const dd = String(dateObj.getDate()).padStart(2, '0');
    const rand = Math.floor(100 + Math.random() * 900);
    const bookingId = `SKG-${yyyy}${mm}${dd}-${rand}`;

    recentSubmissions.set(submissionKey, { bookingId, timestamp: now });

    // Submission formatted date/time (IST & UTC)
    const submissionDateTimeStr = new Intl.DateTimeFormat('en-IN', {
      dateStyle: 'full',
      timeStyle: 'medium',
      timeZone: 'Asia/Kolkata'
    }).format(dateObj);

    // 6. Resend Email Dispatch
    const resendApiKey = process.env.RESEND_API_KEY;
    const hotelEmail = process.env.HOTEL_EMAIL || process.env.BOOKING_NOTIFICATION_EMAIL || 'hotel@example.com';
    const fromSender = process.env.RESEND_FROM_EMAIL || 'Hotel SK Grand <onboarding@resend.dev>';

    // Escape all user input for safe HTML rendering
    const safeName = escapeHtml(fullName);
    const safePhone = escapeHtml(phoneNumber);
    const safeEmail = escapeHtml(email);
    const safeCheckIn = escapeHtml(checkInDate);
    const safeCheckOut = escapeHtml(checkOutDate || checkInDate);
    const safeGuests = escapeHtml(numberOfGuests);
    const safeRoomType = escapeHtml(roomType);
    const safeSpecialRequest = escapeHtml(specialRequest);

    const emailSubject = `New Reservation Request — ${fullName} — Hotel SK Grand`;

    const emailHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${emailSubject}</title>
</head>
<body style="margin: 0; padding: 20px; background-color: #FAF7F2; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #171717; line-height: 1.6;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #FFFFFF; border: 1px solid #E6DEC9; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
    
    <!-- Header Banner -->
    <div style="background-color: #171717; padding: 32px 24px; text-align: center; border-bottom: 3px solid #C6A15B;">
      <h1 style="margin: 0; font-size: 22px; font-weight: 600; letter-spacing: 2px; color: #C6A15B; text-transform: uppercase;">Hotel SK Grand</h1>
      <p style="margin: 6px 0 0 0; font-size: 11px; letter-spacing: 1.5px; color: #FAF7F2; opacity: 0.85; text-transform: uppercase;">Tonk Road, Jaipur · Reservations Desk</p>
      <div style="display: inline-block; margin-top: 14px; padding: 4px 12px; background-color: rgba(198, 161, 91, 0.18); border: 1px solid #C6A15B; border-radius: 4px;">
        <span style="font-size: 12px; font-weight: bold; color: #EADBB6; letter-spacing: 1px;">NEW RESERVATION REQUEST</span>
      </div>
    </div>

    <!-- Booking Summary Badge -->
    <div style="padding: 24px; background-color: #FDFBF7; border-bottom: 1px solid #F0EAE1;">
      <table style="width: 100%; border-collapse: collapse;">
        <tr>
          <td style="font-size: 13px; color: #5C554B;">Reference ID:</td>
          <td style="font-size: 14px; font-weight: bold; text-align: right; color: #A9823F; letter-spacing: 0.5px;">${bookingId}</td>
        </tr>
        <tr>
          <td style="font-size: 13px; color: #5C554B; padding-top: 6px;">Submitted At:</td>
          <td style="font-size: 13px; text-align: right; color: #171717; padding-top: 6px;">${submissionDateTimeStr} (IST)</td>
        </tr>
        <tr>
          <td style="font-size: 13px; color: #5C554B; padding-top: 6px;">Status:</td>
          <td style="font-size: 12px; font-weight: bold; text-align: right; color: #B45309; text-transform: uppercase; padding-top: 6px;">● Pending Hotel Confirmation</td>
        </tr>
      </table>
    </div>

    <!-- Content Area -->
    <div style="padding: 28px 24px;">
      
      <!-- Guest Details -->
      <h2 style="font-size: 14px; text-transform: uppercase; letter-spacing: 1.5px; color: #A9823F; margin: 0 0 12px 0; border-bottom: 1px solid #E6DEC9; padding-bottom: 6px;">
        Guest Details
      </h2>
      <table style="width: 100%; font-size: 14px; border-collapse: collapse; margin-bottom: 24px;">
        <tr>
          <td style="padding: 8px 0; width: 35%; color: #5C554B; font-weight: 500;">Name:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">${safeName}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #5C554B; font-weight: 500;">Phone:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">
            <a href="tel:${safePhone}" style="color: #A9823F; text-decoration: none;">${safePhone}</a>
          </td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #5C554B; font-weight: 500;">Email:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">
            <a href="mailto:${safeEmail}" style="color: #A9823F; text-decoration: none;">${safeEmail}</a>
          </td>
        </tr>
      </table>

      <!-- Stay Details -->
      <h2 style="font-size: 14px; text-transform: uppercase; letter-spacing: 1.5px; color: #A9823F; margin: 0 0 12px 0; border-bottom: 1px solid #E6DEC9; padding-bottom: 6px;">
        Stay Details
      </h2>
      <table style="width: 100%; font-size: 14px; border-collapse: collapse; margin-bottom: 24px;">
        <tr>
          <td style="padding: 8px 0; width: 35%; color: #5C554B; font-weight: 500;">Check-in:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">${safeCheckIn}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #5C554B; font-weight: 500;">Check-out:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">${safeCheckOut}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #5C554B; font-weight: 500;">Guests:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">${safeGuests}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #5C554B; font-weight: 500;">Room Type:</td>
          <td style="padding: 8px 0; color: #171717; font-weight: 600;">${safeRoomType}</td>
        </tr>
      </table>

      <!-- Special Request -->
      <h2 style="font-size: 14px; text-transform: uppercase; letter-spacing: 1.5px; color: #A9823F; margin: 0 0 12px 0; border-bottom: 1px solid #E6DEC9; padding-bottom: 6px;">
        Special Request
      </h2>
      <div style="background-color: #FAF7F2; border: 1px solid #E6DEC9; border-radius: 4px; padding: 14px 16px; margin-bottom: 24px; font-size: 13px; color: #3A352F; font-style: ${specialRequest ? 'normal' : 'italic'};">
        ${specialRequest ? safeSpecialRequest.replace(/\n/g, '<br>') : 'No special requests provided.'}
      </div>

      <!-- Quick Action Prompt for Hotel Staff -->
      <div style="background-color: #F6F4EF; border-left: 4px solid #C6A15B; padding: 14px 16px; border-radius: 2px;">
        <p style="margin: 0; font-size: 12px; color: #5C554B; line-height: 1.5;">
          <strong>Quick Action:</strong> Click "Reply" in your email client to directly email <strong>${safeName}</strong> at <span style="color: #171717;">${safeEmail}</span>, or call <a href="tel:${safePhone}" style="color: #A9823F; font-weight: bold; text-decoration: none;">${safePhone}</a> to confirm the reservation.
        </p>
      </div>

    </div>

    <!-- Footer -->
    <div style="background-color: #171717; padding: 20px 24px; text-align: center; border-top: 1px solid #2B2620;">
      <p style="margin: 0; font-size: 12px; color: #C6A15B; font-weight: 500;">Hotel SK Grand</p>
      <p style="margin: 4px 0 0 0; font-size: 11px; color: #FAF7F2; opacity: 0.7;">Plot No. 1 & 2, Ram Nagar-A, Near Bambala Puliya, Tonk Road, Jaipur</p>
      <p style="margin: 4px 0 0 0; font-size: 11px; color: #FAF7F2; opacity: 0.7;">Phone: +91 98290 63140 | +91 98280 63140</p>
    </div>

  </div>
</body>
</html>
`;

    // 7. Dispatch via Resend SDK
    if (resendApiKey && !resendApiKey.includes('xxxx') && !resendApiKey.includes('123456')) {
      const resendClient = new Resend(resendApiKey);

      console.log(`[Resend Dispatch] Sending reservation email to hotel: ${hotelEmail}`);
      const resendResponse = await resendClient.emails.send({
        from: fromSender,
        to: [hotelEmail],
        replyTo: email, // Direct reply to guest email
        subject: emailSubject,
        html: emailHtml
      });

      if (resendResponse.error) {
        console.error('[Resend Error] Failed to send reservation email:', resendResponse.error);
        return res.status(500).json({
          success: false,
          message: 'Unable to send reservation request. Please try again.'
        });
      }

      console.log(`[Resend Success] Email sent successfully. ID: ${resendResponse.data?.id}`);

      // Optional future hook: send confirmation copy to guest once domain is verified
      // await sendGuestConfirmationEmail(resendClient, fromSender, email, fullName, bookingId);

      return res.status(200).json({
        success: true,
        message: 'Reservation request sent successfully.',
        bookingId
      });
    } else {
      // Local development fallback / simulation mode
      console.warn('===========================================================');
      console.warn('[Resend Notice] RESEND_API_KEY is not configured or is a placeholder.');
      console.warn(`[Local Dev] Simulation: Reservation email generated for ${hotelEmail}`);
      console.warn(`- Booking ID: ${bookingId}`);
      console.warn(`- Guest: ${fullName} (${email}, ${phoneNumber})`);
      console.warn(`- Room: ${roomType}, Check-in: ${checkInDate}, Check-out: ${checkOutDate}`);
      console.warn('===========================================================');

      return res.status(200).json({
        success: true,
        message: 'Reservation request sent successfully.',
        bookingId
      });
    }

  } catch (err: any) {
    console.error('CRITICAL reservation API error:', err?.message || err);
    return res.status(500).json({
      success: false,
      message: 'Unable to send reservation request. Please try again.'
    });
  }
}

/**
 * Optional guest confirmation email structure:
 * Can be enabled once a custom domain is verified in Resend (e.g. reservations@hotelskgrand.in).
 * Currently disabled to ensure free/sandbox compatibility where sending is restricted to account owner.
 */
export async function sendGuestConfirmationEmail(
  resendClient: Resend,
  fromSender: string,
  guestEmail: string,
  guestName: string,
  bookingId: string
) {
  try {
    await resendClient.emails.send({
      from: fromSender,
      to: [guestEmail],
      subject: `Reservation Request Received — Hotel SK Grand (${bookingId})`,
      html: `<p>Dear ${escapeHtml(guestName)},</p><p>We have received your reservation request (${bookingId}). Our front desk will contact you shortly.</p>`
    });
  } catch (e) {
    console.warn('Guest confirmation email delivery skipped/failed:', e);
  }
}
