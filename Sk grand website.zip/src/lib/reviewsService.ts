export interface Review {
  id: string;
  name: string;
  email: string;
  rating: number; // 1 to 5
  title: string;
  message: string;
  stayType?: 'Business' | 'Couple' | 'Family' | 'Solo' | 'Other';
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

const STORAGE_KEY = 'sk_grand_reviews_v1';

const INITIAL_APPROVED_REVIEWS: Review[] = [
  {
    id: 'rev-01',
    name: 'Rajesh Sharma',
    email: 'rajesh.s@example.com',
    rating: 5,
    title: 'Exceptional Hospitality and Cleanliness',
    message: 'We stayed in the Super Deluxe room on Tonk Road. The staff was incredibly welcoming, the room was sparkling clean with a great view, and breakfast at the restaurant was delicious.',
    stayType: 'Family',
    status: 'approved',
    createdAt: '2026-07-28T10:30:00Z'
  },
  {
    id: 'rev-02',
    name: 'Priya & Vikram Mehta',
    email: 'p.mehta@example.com',
    rating: 5,
    title: 'Serene and Luxury Stay in Jaipur',
    message: 'Beautiful hotel with high-speed WiFi and very peaceful atmosphere. Convenient access to Jaipur airport and main city attraction centers.',
    stayType: 'Couple',
    status: 'approved',
    createdAt: '2026-07-20T14:15:00Z'
  },
  {
    id: 'rev-03',
    name: 'Amitabh Roy',
    email: 'amitabh.roy@example.com',
    rating: 4,
    title: 'Great Choice for Corporate Visits',
    message: 'Excellent location on Tonk Road with quick access to JECC. Fast room service, clean bathrooms with hot geyser, and very helpful front desk management.',
    stayType: 'Business',
    status: 'approved',
    createdAt: '2026-07-12T09:45:00Z'
  },
  {
    id: 'rev-04',
    name: 'Sunita Agarwal',
    email: 'sunita.ag@example.com',
    rating: 5,
    title: 'Wonderful Family Reunion & Banquet Celebration',
    message: 'We hosted a family function in the SK Grand Banquet Hall and stayed in the Family Room. Impeccable event management, beautiful decor, and courteous staff throughout.',
    stayType: 'Family',
    status: 'approved',
    createdAt: '2026-06-30T18:20:00Z'
  },
  {
    id: 'rev-05',
    name: 'Dr. Karan Verma',
    email: 'karan.v@example.com',
    rating: 5,
    title: 'Quiet, Comfortable, and Great Value',
    message: 'Slept very peacefully. The air conditioning and LED TV worked flawlessly. Highly recommended for short or long visits to Pratap Nagar and Tonk Road.',
    stayType: 'Solo',
    status: 'approved',
    createdAt: '2026-06-18T11:10:00Z'
  },
  {
    id: 'rev-06',
    name: 'Neha Kapoor',
    email: 'neha.k@example.com',
    rating: 4,
    title: 'Delightful Jaipur Getaway',
    message: 'Loved the bathtub facility and prompt in-room dining service. Very clean, quiet, and well-maintained property.',
    stayType: 'Couple',
    status: 'approved',
    createdAt: '2026-06-05T16:40:00Z'
  }
];

function loadReviews(): Review[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_APPROVED_REVIEWS));
      return INITIAL_APPROVED_REVIEWS;
    }
    const parsed = JSON.parse(data);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch (e) {
    console.error('Failed to load reviews from localStorage', e);
  }
  return INITIAL_APPROVED_REVIEWS;
}

function saveReviews(reviews: Review[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reviews));
  } catch (e) {
    console.error('Failed to save reviews to localStorage', e);
  }
}

export const reviewsService = {
  getAllReviews(): Review[] {
    return loadReviews();
  },

  getApprovedReviews(): Review[] {
    return loadReviews().filter(r => r.status === 'approved');
  },

  getRatingSummary() {
    const approved = this.getApprovedReviews();
    const totalReviews = approved.length;
    if (totalReviews === 0) {
      return {
        averageRating: 5.0,
        totalReviews: 0,
        starDistribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
      };
    }

    const sum = approved.reduce((acc, r) => acc + r.rating, 0);
    const averageRating = Number((sum / totalReviews).toFixed(1));

    const starDistribution: Record<number, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    approved.forEach(r => {
      const rounded = Math.min(5, Math.max(1, Math.round(r.rating)));
      starDistribution[rounded] = (starDistribution[rounded] || 0) + 1;
    });

    return {
      averageRating,
      totalReviews,
      starDistribution
    };
  },

  submitReview(input: {
    name: string;
    email: string;
    rating: number;
    title: string;
    message: string;
    stayType?: 'Business' | 'Couple' | 'Family' | 'Solo' | 'Other';
  }): Review {
    const all = loadReviews();
    const newReview: Review = {
      id: `rev-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: input.name.trim(),
      email: input.email.trim(),
      rating: Math.min(5, Math.max(1, input.rating)),
      title: input.title.trim(),
      message: input.message.trim(),
      stayType: input.stayType || 'Other',
      status: 'pending', // CRITICAL: Always set to pending for moderation
      createdAt: new Date().toISOString()
    };

    const updated = [newReview, ...all];
    saveReviews(updated);
    return newReview;
  }
};
