export interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
}

export type IntentType =
  | 'LOCATION'
  | 'AIRPORT'
  | 'JECC'
  | 'CHOKHI_DHANI'
  | 'SITAPURA'
  | 'ROOMS'
  | 'DELUXE_ROOM'
  | 'SUPER_DELUXE_ROOM'
  | 'SUITE_ROOM'
  | 'FAMILY_ROOM'
  | 'ROOM_AMENITIES'
  | 'WIFI'
  | 'PARKING'
  | 'RESTAURANT'
  | 'BREAKFAST'
  | 'ROOM_SERVICE'
  | 'BANQUET'
  | 'WEDDING'
  | 'EVENT'
  | 'CHECK_IN'
  | 'CHECK_OUT'
  | 'BOOKING'
  | 'CANCELLATION'
  | 'PAYMENT'
  | 'AIRPORT_TRANSFER'
  | 'REVIEWS'
  | 'CONTACT'
  | 'PRICING_ENQUIRY'
  | 'UNKNOWN';

export const HOTEL_KNOWLEDGE = {
  name: 'Hotel SK Grand',
  tagline: 'Luxury Stay on Tonk Road, Jaipur',
  address: 'Plot No. 1–2, Ram Nagar-A, Near Bambala Puliya, JECC, Sitapura, Tonk Road, Sanganer, Jaipur, Rajasthan 302033',
  phone: '+91 98290 63140',
  email: 'info@hotelskgrand.com',
  distances: {
    airport: 'Jaipur International Airport is approximately 5 km away.',
    jecc: 'Jaipur Exhibition & Convention Centre (JECC) is approximately 1 km away.',
    chokhiDhani: 'Chokhi Dhani Cultural Village is approximately 2 km away.',
    sitapura: 'Sitapura Industrial Area is approximately 1 km away.'
  },
  rooms: [
    {
      name: 'Deluxe Room',
      desc: 'King-size comfortable plush bed, LED flat-screen TV with satellite channels, tea & coffee maker, private attached bathroom with 24/7 hot geyser, electronic digital safe box, climate-control AC, minibar/refrigerator, soundproofed double-glazed windows, writing desk with ergonomic chair, electronic keycard entry lock.'
    },
    {
      name: 'Super Deluxe Room',
      desc: 'Spacious refined ambiance featuring premium luxury bedding, modern aesthetic decor, high-speed Wi-Fi, premium toiletries, bathrobes, work desk, and enhanced city view.'
    },
    {
      name: 'Suite Room',
      desc: 'Opulent suite featuring a separate elegant living lounge, premium king bed, luxurious bathtub facility, upgraded work and relaxation amenities, and premium hospitality service.'
    },
    {
      name: 'Family Room',
      desc: 'Generously proportioned room designed specifically for family comfort, featuring multiple plush beds, ample seating space, and modern conveniences.'
    }
  ],
  amenities: [
    'Free High-Speed Wi-Fi',
    'Free Onsite Parking',
    'Climate-Control Air Conditioning',
    'In-House Restaurant & Dining',
    '24/7 Room Service & Housekeeping',
    'Laundry Service',
    'Elevator / Lift',
    'Power Backup',
    'Luggage Assistance',
    'Doctor on Call',
    'Multilingual Front Desk Staff',
    'First-Aid Facilities & CCTV Security',
    'Banquet & Conference Facilities'
  ],
  restaurant: {
    desc: 'Hotel SK Grand features an in-house restaurant offering delicious multi-cuisine dining options and prompt room service.',
    note: 'Exact operating timings, daily menu specials, and food prices vary and are best confirmed directly with the front desk.'
  },
  banquet: {
    desc: 'Hotel SK Grand provides elegant banquet and event facilities suitable for weddings, engagements, ring ceremonies, family functions, and corporate gatherings.',
    capacity: 'Approximately 150 seated capacity and 200 floating capacity with around 25 car parking spaces.',
    note: 'Exact event packages, decoration, catering prices, and date availability require a direct discussion with our event management desk.'
  },
  policies: {
    checkIn: 'Standard check-in time is 2:00 PM. (Please contact Hotel SK Grand directly to confirm exact check-in requirements or early arrivals).',
    checkOut: 'Standard check-out time is 11:00 AM. (Please contact the hotel to confirm late checkout requests).',
    parking: 'Free onsite parking is available for hotel guests.',
    airportTransfer: 'Airport transfer can be arranged as a paid guest service upon request.',
    pricing: 'Current room rates, banquet package pricing, and live availability are not stored in the offline knowledge base. Please use our website booking/enquiry options or contact us directly at +91 98290 63140.'
  }
};

export function classifyIntent(query: string): IntentType {
  const q = query.toLowerCase().trim();

  // Location / Address / Distance
  if (q.includes('address') || q.includes('kaha hai') || q.includes('location') || q.includes('where is') || q.includes('map') || q.includes('reach')) {
    if (q.includes('airport') || q.includes('flight')) return 'AIRPORT';
    if (q.includes('jecc')) return 'JECC';
    if (q.includes('chokhi dhani') || q.includes('chokhidhani')) return 'CHOKHI_DHANI';
    if (q.includes('sitapura')) return 'SITAPURA';
    return 'LOCATION';
  }

  if (q.includes('airport') || q.includes('flight') || q.includes('plane')) {
    if (q.includes('transfer') || q.includes('cab') || q.includes('pickup') || q.includes('drop')) return 'AIRPORT_TRANSFER';
    return 'AIRPORT';
  }

  if (q.includes('jecc') || q.includes('convention')) return 'JECC';
  if (q.includes('chokhi') || q.includes('dhani')) return 'CHOKHI_DHANI';
  if (q.includes('sitapura')) return 'SITAPURA';

  // Rooms & Accommodations
  if (q.includes('super deluxe') || q.includes('super-deluxe')) return 'SUPER_DELUXE_ROOM';
  if (q.includes('suite')) return 'SUITE_ROOM';
  if (q.includes('family')) return 'FAMILY_ROOM';
  if (q.includes('deluxe')) return 'DELUXE_ROOM';
  if (q.includes('room') || q.includes('stay') || q.includes('accommodation') || q.includes('bed')) return 'ROOMS';

  // Amenities & Facilities
  if (q.includes('wifi') || q.includes('wi-fi') || q.includes('internet')) return 'WIFI';
  if (q.includes('parking') || q.includes('car') || q.includes('vehicle')) return 'PARKING';
  if (q.includes('breakfast') || q.includes('nashta') || q.includes('tea') || q.includes('coffee')) return 'BREAKFAST';
  if (q.includes('food') || q.includes('restaurant') || q.includes('khana') || q.includes('dining') || q.includes('lunch') || q.includes('dinner')) return 'RESTAURANT';
  if (q.includes('room service') || q.includes('in-room dining')) return 'ROOM_SERVICE';
  if (q.includes('amenities') || q.includes('facilities') || q.includes('features') || q.includes('service')) return 'ROOM_AMENITIES';

  // Banquet & Events
  if (q.includes('wedding') || q.includes('shaadi') || q.includes('marriage')) return 'WEDDING';
  if (q.includes('event') || q.includes('party') || q.includes('function') || q.includes('gathering') || q.includes('ceremony')) return 'EVENT';
  if (q.includes('banquet') || q.includes('hall') || q.includes('marriage garden') || q.includes('party hall')) return 'BANQUET';

  // Policies & Timings
  if (q.includes('check-in') || q.includes('checkin') || q.includes('arrival time')) return 'CHECK_IN';
  if (q.includes('check-out') || q.includes('checkout') || q.includes('departure')) return 'CHECK_OUT';
  if (q.includes('cancel') || q.includes('refund')) return 'CANCELLATION';
  if (q.includes('pay') || q.includes('payment') || q.includes('card') || q.includes('cash') || q.includes('upi')) return 'PAYMENT';

  // Booking & Pricing & Contact
  if (q.includes('book') || q.includes('reservation') || q.includes('reserve') || q.includes('online booking')) return 'BOOKING';
  if (q.includes('price') || q.includes('cost') || q.includes('rate') || q.includes('tariff') || q.includes('paisa') || q.includes('kitna lagega') || q.includes('budget') || q.includes('discount') || q.includes('offer')) return 'PRICING_ENQUIRY';
  if (q.includes('review') || q.includes('rating') || q.includes('feedback')) return 'REVIEWS';
  if (q.includes('contact') || q.includes('phone') || q.includes('call') || q.includes('number') || q.includes('email') || q.includes('reach out')) return 'CONTACT';

  return 'UNKNOWN';
}

export function getBotResponse(query: string): string {
  const intent = classifyIntent(query);

  switch (intent) {
    case 'LOCATION':
      return `Hotel SK Grand is located at ${HOTEL_KNOWLEDGE.address}. It is situated on Tonk Road near Bambala Puliya in Jaipur.`;
    case 'AIRPORT':
      return `📍 ${HOTEL_KNOWLEDGE.distances.airport} Convenient for travelers flying into Jaipur International Airport.`;
    case 'JECC':
      return `📍 ${HOTEL_KNOWLEDGE.distances.jecc} Highly convenient for attendees visiting exhibitions and events at JECC.`;
    case 'CHOKHI_DHANI':
      return `📍 ${HOTEL_KNOWLEDGE.distances.chokhiDhani} Perfect for guests wishing to experience Jaipur's renowned cultural village.`;
    case 'SITAPURA':
      return `📍 ${HOTEL_KNOWLEDGE.distances.sitapura} Ideal accommodation for corporate visitors and business travelers visiting Sitapura Industrial Area.`;
    case 'ROOMS':
      return `Hotel SK Grand offers 4 premium room categories:
1. Deluxe Room
2. Super Deluxe Room
3. Suite Room (with separate living lounge and bathtub)
4. Family Room

All rooms feature air conditioning, comfortable plush bedding, attached modern bathrooms with 24/7 hot geyser, LED TV, and free Wi-Fi.`;
    case 'DELUXE_ROOM':
      return `🛏️ Deluxe Room Features:\n• King-size plush bed\n• LED flat-screen TV with satellite channels\n• Tea & coffee maker with complimentary supplies\n• Private attached bathroom with 24/7 hot geyser\n• In-room electronic digital safe box & minibar\n• Acoustically soundproofed double-glazed windows\n• Writing desk with ergonomic chair`;
    case 'SUPER_DELUXE_ROOM':
      return `🛏️ Super Deluxe Room Features:\n• Spacious refined ambiance with modern aesthetic decor\n• Premium luxury bedding & high-speed Wi-Fi\n• Premium toiletries, bathrobes & work desk\n• Enhanced city view`;
    case 'SUITE_ROOM':
      return `🛏️ Suite Room Features:\n• Opulent suite with separate elegant living lounge\n• Premium king bed & luxurious bathtub facility\n• Upgraded work and relaxation amenities`;
    case 'FAMILY_ROOM':
      return `🛏️ Family Room Features:\n• Generously proportioned room designed specifically for family comfort\n• Multiple plush beds & ample seating space\n• Modern conveniences`;
    case 'ROOM_AMENITIES':
      return `✨ Key Hotel Amenities include:\n• Free High-Speed Wi-Fi & Free Onsite Parking\n• In-House Restaurant & 24/7 Room Service\n• Climate-Control Air Conditioning\n• Laundry Service & Elevator Access\n• 24/7 Power Backup & CCTV Security\n• Banquet & Conference Facilities`;
    case 'WIFI':
      return `📶 High-speed wireless internet access is available free of charge across all guest rooms and public areas at Hotel SK Grand.`;
    case 'PARKING':
      return `🅿️ Yes! Free onsite parking is available for all registered hotel guests.`;
    case 'RESTAURANT':
      return `🍽️ ${HOTEL_KNOWLEDGE.restaurant.desc}\n\nNote: ${HOTEL_KNOWLEDGE.restaurant.note}`;
    case 'BREAKFAST':
      return `🍳 Breakfast options and multi-cuisine dining are available at our in-house restaurant and through room service.`;
    case 'ROOM_SERVICE':
      return `🛎️ Prompt 24/7 room service is available for in-room dining, beverages, and guest assistance.`;
    case 'BANQUET':
      return `🏛️ ${HOTEL_KNOWLEDGE.banquet.desc}\n\nCapacity: ${HOTEL_KNOWLEDGE.banquet.capacity}\n\nNote: ${HOTEL_KNOWLEDGE.banquet.note}`;
    case 'WEDDING':
      return `💍 Yes, Hotel SK Grand banquet hall is ideal for weddings, engagements, and ring ceremonies. For exact event package pricing and date availability, please contact our front desk at ${HOTEL_KNOWLEDGE.phone}.`;
    case 'EVENT':
      return `🎉 Our banquet and event facilities accommodate family functions, corporate gatherings, and celebrations (~150 seated / ~200 floating). Contact us to discuss your event requirements.`;
    case 'CHECK_IN':
      return `🕒 ${HOTEL_KNOWLEDGE.policies.checkIn}`;
    case 'CHECK_OUT':
      return `⏱️ ${HOTEL_KNOWLEDGE.policies.checkOut}`;
    case 'BOOKING':
      return `📅 You can easily book your stay using our online booking section on the website or by calling us directly at ${HOTEL_KNOWLEDGE.phone}.`;
    case 'CANCELLATION':
      return `ancellation policies depend on the rate plan and booking channel selected. Please check your booking confirmation details or contact Hotel SK Grand directly for assistance.`;
    case 'PAYMENT':
      return `💳 Hotel SK Grand accepts standard payment modes including major credit/debit cards, UPI, digital wallets, and cash payments at the front desk.`;
    case 'AIRPORT_TRANSFER':
      return `🚗 ${HOTEL_KNOWLEDGE.policies.airportTransfer}. You may request this service when booking or by contacting the front desk.`;
    case 'REVIEWS':
      return `⭐ Hotel SK Grand maintains a high guest satisfaction rating with numerous verified public reviews praising our cleanliness, polite hospitality, and prime Tonk Road location. You can view verified guest reviews in our Reviews section!`;
    case 'CONTACT':
      return `📞 You can reach Hotel SK Grand at:\n• Phone: ${HOTEL_KNOWLEDGE.phone}\n• Email: ${HOTEL_KNOWLEDGE.email}\n• Address: ${HOTEL_KNOWLEDGE.address}`;
    case 'PRICING_ENQUIRY':
      return `💰 ${HOTEL_KNOWLEDGE.policies.pricing}`;
    case 'UNKNOWN':
    default:
      return `I understand you are asking about Hotel SK Grand on Tonk Road, Jaipur. For specific pricing, live room availability, or customized event arrangements not covered here, please contact us directly at ${HOTEL_KNOWLEDGE.phone} or use our website booking option. How else may I assist you today?`;
  }
}

export const QUICK_QUESTIONS = [
  'Rooms & Facilities',
  'Location & Airport',
  'Restaurant & Dining',
  'Banquet & Weddings',
  'Check-in & Parking',
  'How to Book'
];
