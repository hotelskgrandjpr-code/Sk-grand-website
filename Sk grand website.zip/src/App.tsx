/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Menu, X, MapPin, Phone, Clock, Check, Coffee, Utensils, Compass, 
  ArrowRight, Star, Calendar, Users, ChevronRight, Award, Shield, Wifi, 
  Car, Sparkles, Building2, Eye, ZoomIn, HeartHandshake, MessageCircle, Bed,
  Plus, CheckCircle2, ShieldCheck
} from 'lucide-react';
import { reviewsService } from './lib/reviewsService';
import { ReviewModal } from './components/ReviewModal';
import { ReviewsPage } from './components/ReviewsPage';
import { CinematicLoader } from './components/CinematicLoader';
import { ChatbotWidget } from './components/ChatbotWidget';

type PageId = 
  | 'home' 
  | 'rooms' 
  | 'room-detail' 
  | 'dining' 
  | 'banquet' 
  | 'amenities' 
  | 'gallery' 
  | 'about' 
  | 'location' 
  | 'booking'
  | 'reviews';

type RoomTypeKey = 'deluxe' | 'super-deluxe' | 'suite' | 'family';

interface RoomData {
  key: RoomTypeKey;
  name: string;
  category: string;
  tagline: string;
  description: string;
  priceNote: string;
  image: string;
  gallery: string[];
  features: string[];
  fullFacilities: string[];
}

const ROOMS_DATA: Record<RoomTypeKey, RoomData> = {
  'deluxe': {
    key: 'deluxe',
    name: 'Deluxe Room',
    category: 'CATEGORY 01',
    tagline: 'Refined tranquility along Tonk Road',
    description: 'Designed for business travelers and tourists seeking comfortable, quiet lodging with modern essentials in Jaipur.',
    priceNote: 'Best Available Rate guaranteed when booking direct',
    image: 'https://cdn.corenexis.com/f/v4fRnCMJylm.jpg',
    gallery: ['https://cdn.corenexis.com/f/v4fRnCMJylm.jpg'],
    features: ['King-sized Bed', 'Air Conditioning & LED TV', 'Minibar & Coffee Maker', 'Soundproofed Windows'],
    fullFacilities: [
      'King-sized comfortable plush bed',
      'Individual climate control air conditioning',
      'LED Flat Screen TV with satellite channels',
      'In-room Minibar and refrigerator',
      'Tea & coffee maker with complimentary supplies',
      'Acoustically soundproofed double-glazed windows',
      'Private attached bathroom with 24/7 hot geyser',
      'Writing desk with ergonomic chair',
      'Ironing board & iron available',
      'Electronic keycard entry lock',
      'In-room electronic digital safe box',
      'Select rooms: Private attached balcony'
    ]
  },
  'super-deluxe': {
    key: 'super-deluxe',
    name: 'Super Deluxe Room',
    category: 'CATEGORY 02',
    tagline: 'Elevated spatial layout with panoramic city views',
    description: 'Generous room dimensions, elevated 3rd floor views over Pratap Nagar, and luxury bathroom fittings for an upgraded stay experience.',
    priceNote: 'Complimentary breakfast included on select packages',
    image: 'https://cdn.corenexis.com/f/5IEiRUBt6eJ.jpg',
    gallery: ['https://cdn.corenexis.com/f/5IEiRUBt6eJ.jpg'],
    features: ['All Deluxe Amenities', 'Bathtub (Select Rooms)', '3rd Floor City View', 'Hair Dryer & Bidet'],
    fullFacilities: [
      'Includes all Deluxe Room standard amenities',
      'Soaking bathtub available in select bathrooms',
      'Elevated 3rd floor views overlooking Pratap Nagar & Tonk Road',
      'In-bathroom hair dryer & bidet sprayer',
      'Separate toilet and vanity area',
      'Private sitting/dining nook inside room',
      'Upgraded premium bath linen & toiletries kit',
      'Daily complimentary bottled water replenish'
    ]
  },
  'suite': {
    key: 'suite',
    name: 'Suite Room',
    category: 'CATEGORY 03 · THE CROWN JEWEL',
    tagline: 'Uncompromised luxury and top-floor Jaipur skyline vistas',
    description: 'Our largest accommodation offering separate seating dimensions, luxury furnishings, and panoramic city vistas.',
    priceNote: 'VIP arrival amenities included',
    image: 'https://cdn.corenexis.com/f/Kwd1D7uPXNI.jpg',
    gallery: [
      'https://cdn.corenexis.com/f/Kwd1D7uPXNI.jpg'
    ],
    features: ['Largest Floor Plan', 'Panoramic Jaipur Views', 'VIP Luxury Furnishings', 'Express Room Service'],
    fullFacilities: [
      'Includes all standard Deluxe and Super Deluxe amenities',
      'Largest interior square footage in the hotel',
      'Expansive top-floor panoramic Jaipur skyline view',
      'Dedicated lounge seating sofa setup',
      'Bespoke hardwood furniture & ambient lighting',
      'Priority 24-hour room service handling',
      'Complimentary welcome fruit basket on arrival',
      'In-suite espresso coffee machine'
    ]
  },
  'family': {
    key: 'family',
    name: 'Family Room',
    category: 'CATEGORY 04',
    tagline: 'Spacious family lodging with premium comfort',
    description: 'Designed for families and groups traveling together, offering multi-bed arrangements, generous spatial layout, and full in-room facilities.',
    priceNote: 'Family package privileges included',
    image: 'https://cdn.phototourl.com/free/2026-09-04-da0d539e-5e95-4b01-bd9e-2a90de0d48b6.jpg',
    gallery: [
      'https://cdn.phototourl.com/free/2026-09-04-da0d539e-5e95-4b01-bd9e-2a90de0d48b6.jpg'
    ],
    features: ['Multiple Bed Layouts', 'Generous Spatial Layout', 'In-room Dining Nook', 'Family Amenities'],
    fullFacilities: [
      'Includes all standard Deluxe and Super Deluxe amenities',
      'Multiple sleeping arrangements ideal for families & groups',
      'Spacious sitting & dining nook within room',
      'Large attached bathroom with 24/7 hot geyser & vanity',
      'Complimentary breakfast included on select packages',
      'In-room entertainment with LED TV & satellite channels',
      'Individual climate control air conditioning',
      'Daily complimentary bottled water replenish'
    ]
  }
};

const GALLERY_IMAGES: Array<{ id: number; category: string; title: string; src: string }> = [
  { id: 1, category: 'Rooms', title: 'Deluxe Guest Room', src: 'https://cdn.corenexis.com/f/v4fRnCMJylm.jpg' },
  { id: 2, category: 'Rooms', title: 'Super Deluxe Room', src: 'https://cdn.corenexis.com/f/5IEiRUBt6eJ.jpg' },
  { id: 3, category: 'Rooms', title: 'Suite Room Luxury Living', src: 'https://cdn.corenexis.com/f/Kwd1D7uPXNI.jpg' },
  { id: 5, category: 'Rooms', title: 'Family Room Suite', src: 'https://cdn.phototourl.com/free/2026-09-04-da0d539e-5e95-4b01-bd9e-2a90de0d48b6.jpg' },
  { id: 10, category: 'Restaurant', title: 'Fine Dining Experience', src: 'https://cdn.phototourl.com/free/2026-09-04-ce3a7f52-c84a-437a-b8ab-52b43ea6e02d.jpg' },
  { id: 11, category: 'Banquet', title: 'Grand Banquet Celebration - View 1', src: 'https://cdn.phototourl.com/free/2026-09-04-7ccd586e-bb4f-4f4d-b25c-506d3941592a.jpg' },
  { id: 110, category: 'Banquet', title: 'Grand Banquet Celebration - View 2', src: 'https://cdn.phototourl.com/free/2026-09-04-df86f18c-d9cb-4aad-92fe-1e99862c97c2.jpg' },
  { id: 13, category: 'Hotel', title: 'Hotel SK Grand Ambience - View 1', src: 'https://cdn.phototourl.com/member/2026-09-04-47cfe3a7-3ec0-4bf6-a166-0e483f03f7b1.jpg' },
  { id: 14, category: 'Hotel', title: 'Hotel SK Grand Ambience - View 2', src: 'https://cdn.phototourl.com/member/2026-09-04-fe9ce0af-643f-4ce9-9420-883fb067c726.jpg' },
  { id: 15, category: 'Hotel', title: 'Hotel SK Grand Ambience - View 3', src: 'https://cdn.phototourl.com/member/2026-09-04-421bdb9f-9952-48a9-93b1-97d92e1f81cd.jpg' },
  { id: 16, category: 'Hotel', title: 'Hotel SK Grand Ambience - View 4', src: 'https://cdn.phototourl.com/member/2026-09-04-262fa6a6-9fb4-40d0-aa04-5a285acacf09.jpg' },
];

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [selectedRoomKey, setSelectedRoomKey] = useState<RoomTypeKey>('deluxe');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isCinematicLoading, setIsCinematicLoading] = useState(true);

  // Reviews System State
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewsSummary, setReviewsSummary] = useState(() => reviewsService.getRatingSummary());
  const [approvedReviews, setApprovedReviews] = useState(() => reviewsService.getApprovedReviews());

  const refreshReviews = useCallback(() => {
    setReviewsSummary(reviewsService.getRatingSummary());
    setApprovedReviews(reviewsService.getApprovedReviews());
  }, []);

  // Gallery Filter & Lightbox
  const [galleryFilter, setGalleryFilter] = useState('All');
  const [activeLightboxImg, setActiveLightboxImg] = useState<string | null>(null);

  // Animation States
  const [initialCurtainVisible, setInitialCurtainVisible] = useState(true);
  const [initialCurtainOpen, setInitialCurtainOpen] = useState(false);
  const [banquetCurtainOpen, setBanquetCurtainOpen] = useState(false);
  const [diningSweepActive, setDiningSweepActive] = useState(false);

  // Shared Observer Ref
  const observerRef = useRef<IntersectionObserver | null>(null);

  // Hero Video Intersection Observer Refs
  const heroVideoRef = useRef<HTMLVideoElement | null>(null);
  const heroSectionRef = useRef<HTMLElement | null>(null);
  const hasLeftHeroRef = useRef<boolean>(false);

  // Booking Form State
  const [bookingCategory, setBookingCategory] = useState<'room' | 'banquet'>('room');
  const [bookingStep, setBookingStep] = useState(1);
  const [bookingData, setBookingData] = useState({
    checkIn: '',
    checkOut: '',
    guests: '2 Guests',
    roomType: 'Deluxe Room',
    eventType: 'Wedding',
    eventDate: '',
    banquetGuests: '100 - 250 Guests',
    name: '',
    phone: '',
    email: '',
    specialRequests: ''
  });
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [isSubmittingBooking, setIsSubmittingBooking] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [serverBookingId, setServerBookingId] = useState<string | null>(null);

  // Animation Re-initialization
  const initPageAnimations = useCallback((pageId: PageId) => {
    setTimeout(() => {
      // 2. Character & Word Split Reveal for H1 & H2 (Preserves word boundary)
      const headings = document.querySelectorAll('main h1, main h2');
      headings.forEach((h) => {
        const el = h as HTMLElement;
        if (!el.dataset.splitDone && !el.classList.contains('no-split')) {
          const text = el.textContent || '';
          el.dataset.splitDone = 'true';
          const words = text.split(' ');
          let charIdx = 0;
          el.innerHTML = words.map(word => {
            const wordChars = [...word].map(c => {
              const delay = (charIdx * 0.03).toFixed(2);
              charIdx++;
              return `<span class="char-reveal" style="animation-delay:${delay}s">${c}</span>`;
            }).join('');
            charIdx++; // account for space
            return `<span class="inline-block whitespace-nowrap">${wordChars}</span>`;
          }).join(' ');
        }
      });

      // 3. Re-observe data-reveal elements
      if (observerRef.current) {
        document.querySelectorAll('[data-reveal]').forEach((el) => {
          if (!el.classList.contains('revealed')) {
            observerRef.current?.observe(el);
          }
        });
      }

      // Desktop-only interactive mouse effects
      if (!('ontouchstart' in window) && window.matchMedia('(pointer: fine)').matches) {
        // 4. Cursor magnetic effect
        const buttons = document.querySelectorAll('.btn-primary, .explore-btn, .hero-cta, .back-home-btn, .directions-btn');
        buttons.forEach((btn) => {
          const button = btn as HTMLElement;
          if (button.dataset.magneticBound) return;
          button.dataset.magneticBound = 'true';

          button.addEventListener('mousemove', (e: Event) => {
            const mouseEvent = e as MouseEvent;
            const rect = button.getBoundingClientRect();
            const dx = (mouseEvent.clientX - rect.left - rect.width / 2) * 0.3;
            const dy = (mouseEvent.clientY - rect.top - rect.height / 2) * 0.3;
            button.style.transition = 'none';
            button.style.transform = `translate(${dx}px, ${dy}px)`;
          });

          button.addEventListener('mouseleave', () => {
            button.style.transition = 'transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
            button.style.transform = 'translate(0, 0)';
          });
        });

        // 6. 3D Card Tilt
        const cards = document.querySelectorAll('.tilt-card, .preview-card, .room-card, .amenity-card, .gallery-item');
        cards.forEach((cardEl) => {
          const card = cardEl as HTMLElement;
          if (card.dataset.tiltBound) return;
          card.dataset.tiltBound = 'true';

          card.addEventListener('mousemove', (e: Event) => {
            const mouseEvent = e as MouseEvent;
            const rect = card.getBoundingClientRect();
            const x = mouseEvent.clientX - rect.left - rect.width / 2;
            const y = mouseEvent.clientY - rect.top - rect.height / 2;
            const rotateX = (y / rect.height) * -10;
            const rotateY = (x / rect.width) * 10;
            card.style.transition = 'none';
            card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
          });

          card.addEventListener('mouseleave', () => {
            card.style.transition = 'transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
            card.style.transform = 'perspective(800px) rotateX(0) rotateY(0) scale(1)';
          });
        });

        // 5. Hero mouse-tracking spotlight
        if (pageId === 'home') {
          const hero = document.querySelector('.hero') as HTMLElement;
          if (hero && !hero.dataset.spotlightBound) {
            hero.dataset.spotlightBound = 'true';
            hero.addEventListener('mousemove', (e: Event) => {
              const mouseEvent = e as MouseEvent;
              const rect = hero.getBoundingClientRect();
              hero.style.setProperty('--mx', `${((mouseEvent.clientX - rect.left) / rect.width) * 100}%`);
              hero.style.setProperty('--my', `${((mouseEvent.clientY - rect.top) / rect.height) * 100}%`);
            });
          }
        }
      }
    }, 100);
  }, []);

  useEffect(() => {
    // 10. Scroll Progress Listener
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const currentScroll = window.scrollY;
      setIsScrolled(currentScroll > 20);
      setScrollProgress((currentScroll / (totalHeight || 1)) * 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    // 3. Single Shared Intersection Observer
    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observerRef.current?.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    // 1. Initial Page Load Curtain Reveal
    const curtainTimer1 = setTimeout(() => setInitialCurtainOpen(true), 200);
    const curtainTimer2 = setTimeout(() => setInitialCurtainVisible(false), 1600);

    initPageAnimations('home');

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(curtainTimer1);
      clearTimeout(curtainTimer2);
      observerRef.current?.disconnect();
    };
  }, [initPageAnimations]);

  // Hero Video Scroll Replay Observer
  useEffect(() => {
    if (currentPage !== 'home' || !heroSectionRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            // User scrolled away from Hero section
            hasLeftHeroRef.current = true;
          } else {
            // User returned to or is viewing Hero section
            if (hasLeftHeroRef.current) {
              hasLeftHeroRef.current = false;
              if (heroVideoRef.current) {
                heroVideoRef.current.currentTime = 0;
                heroVideoRef.current.play().catch(() => {
                  // handle playback restriction gracefully
                });
              }
            }
          }
        });
      },
      { threshold: 0.25 }
    );

    observer.observe(heroSectionRef.current);

    return () => {
      observer.disconnect();
    };
  }, [currentPage]);

  const openBooking = (category: 'room' | 'banquet' = 'room', roomKey?: RoomTypeKey) => {
    setBookingCategory(category);
    setBookingStep(1);
    setBookingConfirmed(false);
    if (category === 'room' && roomKey) {
      setBookingData(prev => ({
        ...prev,
        roomType: ROOMS_DATA[roomKey].name
      }));
    }
    showPage('booking');
  };

  const showPage = (pageId: PageId, roomKey?: RoomTypeKey) => {
    if (pageId === 'room-detail' && roomKey) {
      setSelectedRoomKey(roomKey);
    } else if (pageId === 'booking' && roomKey) {
      setBookingData(prev => ({
        ...prev,
        roomType: ROOMS_DATA[roomKey].name
      }));
    }

    if (pageId === currentPage && !roomKey) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setMobileMenuOpen(false);
      return;
    }

    setIsTransitioning(true);
    setMobileMenuOpen(false);

    // Page-specific special triggers
    if (pageId === 'banquet') {
      setBanquetCurtainOpen(false);
      setTimeout(() => setBanquetCurtainOpen(true), 350);
    } else if (pageId === 'dining') {
      setDiningSweepActive(false);
      setTimeout(() => setDiningSweepActive(true), 350);
    }

    setTimeout(() => {
      setCurrentPage(pageId);
      window.scrollTo(0, 0);
      setTimeout(() => {
        setIsTransitioning(false);
        initPageAnimations(pageId);
      }, 50);
    }, 300);
  };

  const handleBanquetNav = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (currentPage === 'home') {
      const el = document.getElementById('banquet-hall-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      showPage('home');
      setTimeout(() => {
        const el = document.getElementById('banquet-hall-section');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 400);
    }
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const maxSteps = bookingCategory === 'banquet' ? 2 : 3;
    if (bookingStep < maxSteps) {
      setBookingStep(bookingStep + 1);
      setBookingError(null);
    } else {
      setIsSubmittingBooking(true);
      setBookingError(null);
      try {
        const payload = {
          fullName: bookingData.name,
          phoneNumber: bookingData.phone,
          email: bookingData.email,
          checkInDate: bookingCategory === 'room' ? bookingData.checkIn : bookingData.eventDate,
          checkOutDate: bookingCategory === 'room' ? bookingData.checkOut : bookingData.eventDate,
          numberOfGuests: bookingCategory === 'room' ? bookingData.guests : bookingData.banquetGuests,
          roomType: bookingCategory === 'room' ? bookingData.roomType : `Banquet: ${bookingData.eventType}`,
          specialRequest: bookingData.specialRequests,
          category: bookingCategory,
          name: bookingData.name,
          phone: bookingData.phone,
          checkIn: bookingCategory === 'room' ? bookingData.checkIn : bookingData.eventDate,
          checkOut: bookingCategory === 'room' ? bookingData.checkOut : bookingData.eventDate,
          guests: bookingCategory === 'room' ? bookingData.guests : bookingData.banquetGuests,
        };

        const res = await fetch('/api/reservation', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (res.ok && data.success) {
          setServerBookingId(data.bookingId || `SKG-${Date.now().toString().slice(-6)}`);
          setBookingConfirmed(true);
          // Reset form fields after successful submission
          setBookingData({
            checkIn: '',
            checkOut: '',
            guests: '2 Guests',
            roomType: 'Deluxe Room',
            eventType: 'Wedding',
            eventDate: '',
            banquetGuests: '100 - 250 Guests',
            name: '',
            phone: '',
            email: '',
            specialRequests: ''
          });
        } else {
          setBookingError(data.message || data.error || "Unable to send reservation request. Please try again.");
        }
      } catch (err) {
        console.error("Booking submission error:", err);
        setBookingError("Unable to send reservation request. Please try again.");
      } finally {
        setIsSubmittingBooking(false);
      }
    }
  };

  const activeRoomData = ROOMS_DATA[selectedRoomKey];

  return (
    <div className="min-h-screen w-full bg-[#FAF7F2] text-[#171717] font-sans selection:bg-[#C6A15B]/30 selection:text-[#171717] overflow-x-hidden">
      
      {/* CINEMATIC LOADING SCREEN */}
      {isCinematicLoading && (
        <CinematicLoader onComplete={() => setIsCinematicLoading(false)} />
      )}

      {/* 1. INITIAL PAGE LOAD CURTAIN REVEAL */}
      {initialCurtainVisible && (
        <>
          <div className={`curtain curtain-top ${initialCurtainOpen ? 'open' : ''}`} />
          <div className={`curtain curtain-bottom ${initialCurtainOpen ? 'open' : ''}`} />
        </>
      )}

      {/* 10. SCROLL PROGRESS BAR */}
      <div className="scroll-progress" style={{ width: `${scrollProgress}%` }} />

      {/* FIXED GLASSMORPHISM NAVBAR */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out ${
        isScrolled ? 'glass-header scrolled py-3 sm:py-3.5' : 'glass-header py-4 sm:py-5'
      }`}>
        <div className="max-w-[1440px] mx-auto px-6 sm:px-10 flex justify-between items-center">
          {/* LOGO */}
          <button 
            onClick={() => showPage('home')}
            className="flex items-center space-x-3 text-left cursor-pointer group focus:outline-none"
            aria-label="Hotel SK Grand Home"
          >
            <img 
              src="https://cdn.phototourl.com/member/2026-09-04-7a09cda6-9890-4a86-a1e5-5c33a2c48640.png" 
              alt="Hotel SK Grand Logo" 
              className="h-11 sm:h-13 w-auto object-contain transition-transform duration-300 group-hover:scale-105 filter drop-shadow-md"
            />
          </button>

          {/* DESKTOP NAV LINKS */}
          <nav className="hidden lg:flex items-center space-x-6 text-[11px] uppercase tracking-[0.25em] font-medium">
            <a data-page="home" onClick={() => showPage('home')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'home' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Home</a>
            <a data-page="rooms" onClick={() => showPage('rooms')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'rooms' || currentPage === 'room-detail' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Rooms</a>
            <a data-page="dining" onClick={() => showPage('dining')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'dining' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Dining</a>
            <a data-page="banquet" onClick={handleBanquetNav} className={`py-1 cursor-pointer transition-colors ${currentPage === 'banquet' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Banquet</a>
            <a data-page="amenities" onClick={() => showPage('amenities')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'amenities' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Amenities</a>
            <a data-page="gallery" onClick={() => showPage('gallery')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'gallery' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Gallery</a>
            <a data-page="reviews" onClick={() => showPage('reviews')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'reviews' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Reviews</a>
            <a data-page="about" onClick={() => showPage('about')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'about' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Our Story</a>
            <a data-page="location" onClick={() => showPage('location')} className={`py-1 cursor-pointer transition-colors ${currentPage === 'location' ? 'nav-active' : 'text-[#171717] hover:text-[#C6A15B]'}`}>Location</a>
            
            <a 
              href="tel:+919829063140" 
              className="glass-pill inline-flex items-center space-x-2 text-[#171717] hover:text-[#A9823F] px-3.5 py-1.5 cursor-pointer font-medium tracking-wider normal-case text-xs shadow-sm"
              title="Call Hotel SK Grand"
            >
              <Phone size={13} className="text-[#C6A15B]" />
              <span>+91 98290 63140</span>
            </a>

            <button 
              data-page="booking"
              onClick={() => openBooking('room')}
              className="glass-btn-gold px-5 py-2 text-[10px] tracking-[0.2em] uppercase cursor-pointer font-semibold shadow-md"
            >
              Book Now
            </button>
          </nav>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden text-[#171717] p-2 focus:outline-none cursor-pointer glass-pill"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* MOBILE GLASS DRAWER MENU */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 glass-drawer p-8 flex flex-col justify-center space-y-5 pt-20">
          <div className="absolute top-6 left-8 right-8 flex items-center justify-between">
            <img 
              src="https://cdn.phototourl.com/member/2026-09-04-7a09cda6-9890-4a86-a1e5-5c33a2c48640.png" 
              alt="Hotel SK Grand Logo" 
              className="h-11 w-auto object-contain filter drop-shadow-md"
            />
            <button 
              onClick={() => setMobileMenuOpen(false)}
              className="text-[#171717] p-2 focus:outline-none cursor-pointer glass-pill"
              aria-label="Close Navigation"
            >
              <X size={22} />
            </button>
          </div>
          {[
            { id: 'home', label: 'Home' },
            { id: 'rooms', label: 'Rooms' },
            { id: 'dining', label: 'Dining' },
            { id: 'banquet', label: 'Banquet' },
            { id: 'amenities', label: 'Amenities' },
            { id: 'gallery', label: 'Gallery' },
            { id: 'reviews', label: 'Guest Reviews' },
            { id: 'about', label: 'Our Story' },
            { id: 'location', label: 'Location' },
            { id: 'booking', label: 'Book Now' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setMobileMenuOpen(false);
                if (item.id === 'banquet') {
                  handleBanquetNav();
                } else if (item.id === 'booking') {
                  openBooking('room');
                } else {
                  showPage(item.id as PageId);
                }
              }}
              className={`font-luxury text-2xl sm:text-3xl text-left tracking-[0.15em] transition-all cursor-pointer ${
                currentPage === item.id ? 'text-[#A9823F] font-bold pl-3 border-l-2 border-[#C6A15B]' : 'text-[#171717] hover:text-[#C6A15B]'
              }`}
            >
              {item.label.toUpperCase()}
            </button>
          ))}

          <div className="pt-4 border-t border-[#C6A15B]/20 flex flex-col space-y-3">
            <a 
              href="tel:+919829063140" 
              className="glass-pill flex items-center space-x-3 text-[#171717] hover:text-[#A9823F] text-sm px-4 py-3 font-medium"
            >
              <Phone size={18} className="text-[#C6A15B]" />
              <span>Call Primary: +91 98290 63140</span>
            </a>
            <a 
              href="tel:+919828063140" 
              className="glass-pill flex items-center space-x-3 text-[#171717] hover:text-[#A9823F] text-sm px-4 py-3 font-medium"
            >
              <Phone size={18} className="text-[#C6A15B]" />
              <span>Call Secondary: +91 98280 63140</span>
            </a>
            <a 
              href="https://wa.me/919829063140?text=Hello%20Hotel%20SK%20Grand,%20I%20would%20like%20to%20enquire%20about%20a%20booking.%20Please%20share%20the%20availability%20and%20details." 
              target="_blank" 
              rel="noopener noreferrer" 
              className="glass-pill flex items-center space-x-3 text-emerald-600 text-sm px-4 py-3 font-medium"
            >
              <MessageCircle size={18} />
              <span>WhatsApp Booking (+91 98290 63140)</span>
            </a>
          </div>
        </div>
      )}

      {/* MAIN CONTENT ROUTER AREA */}
      <main className={`page transition-opacity duration-300 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
        
        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 1: HOME (#page-home) — PREVIEWS ONLY   */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'home' && (
          <section id="page-home" className="w-full">
            
            {/* 1. HERO */}
            <section className="hero" ref={heroSectionRef}>
              <video
                ref={heroVideoRef}
                autoPlay
                muted
                playsInline
                preload="auto"
                className="hero-bg"
              >
                <source src="https://res.cloudinary.com/jmoelmzp/video/upload/lv_0_20260728135051_izsdgf.mp4" type="video/mp4" />
              </video>

              <div className="hero-content" data-reveal="fade-up">
                <p className="hero-eyebrow">
                  EST. 2019 &nbsp;·&nbsp; JAIPUR, RAJASTHAN &nbsp;·&nbsp; ★ 4.1 / 5 &nbsp;(790+ REVIEWS)
                </p>

                <h1 className="hero-title no-split font-luxury font-light text-[#F5F0E8] leading-tight">
                  <span className="inline-block whitespace-nowrap">HOTEL</span>{' '}
                  <span className="inline-block whitespace-nowrap">SK</span>{' '}
                  <span className="inline-block whitespace-nowrap">GRAND</span>
                </h1>

                <p className="hero-tagline">
                  Comfort on Tonk Road, Culture at Your Door. 30 well-appointed rooms and premier hospitality in the heart of Jaipur.
                </p>

                {/* PROMINENT HERO CTAs */}
                <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
                  <button 
                    onClick={() => openBooking('room')}
                    className="hero-cta inline-flex items-center justify-center space-x-2 text-xs py-4 px-10 bg-[#C6A15B] text-[#0D0D0D] font-bold tracking-[0.2em] uppercase hover:bg-[#A9823F] hover:text-white transition-all cursor-pointer shadow-xl min-w-[180px]"
                  >
                    <Calendar size={16} />
                    <span>BOOK NOW</span>
                  </button>
                  <a 
                    href="tel:+919829063140"
                    className="hero-cta inline-flex items-center justify-center space-x-2 text-xs py-4 px-10 border-2 border-[#C6A15B] bg-[#0D0D0D]/60 text-[#FAF7F2] hover:bg-[#C6A15B] hover:text-[#0D0D0D] font-bold tracking-[0.2em] uppercase transition-all cursor-pointer shadow-xl min-w-[180px] backdrop-blur-xs"
                  >
                    <Phone size={16} />
                    <span>CALL NOW</span>
                  </a>
                </div>

                <div className="pt-3">
                  <button 
                    onClick={() => showPage('rooms')}
                    className="text-xs uppercase tracking-[0.2em] text-[#F5F0E8]/80 hover:text-[#C6A15B] transition-colors underline underline-offset-4 cursor-pointer font-medium"
                  >
                    Explore Rooms & Suites →
                  </button>
                </div>
              </div>

              <div className="hero-scroll">
                <span>Scroll</span>
                <div className="hero-scroll-line"></div>
              </div>
            </section>

            {/* 2. LAYERED SCROLL INTRO */}
            <div className="w-full bg-[#FAF7F2] border-y border-[#C6A15B]/20 py-16 px-6 text-center" data-reveal="fade-up">
              <p className="font-luxury text-3xl sm:text-5xl text-[#171717] font-light max-w-4xl mx-auto leading-tight tracking-wide">
                "Thirty rooms. One address. Every comfort of Jaipur."
              </p>
            </div>

            {/* PREVIEW SECTIONS GRID */}
            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-24">

              {/* 3. OUR STORY PREVIEW */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                <span className="section-number top-2 right-4">STORY</span>
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center z-10 relative">
                  <div className="lg:col-span-7 overflow-hidden relative group aspect-[16/10] bg-[#F2ECDE] border border-[#C6A15B]/25" data-reveal="slide-left">
                    <img 
                      src="https://cdn.phototourl.com/free/2026-09-04-90a0f08a-1405-483e-b0d9-6f0c02faa50a.jpg" 
                      alt="Hotel SK Grand Our Story" 
                      className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                    />
                  </div>

                  <div className="lg:col-span-5 space-y-6" data-reveal="slide-right">
                    <div className="inline-flex items-center space-x-3">
                      <span className="w-8 h-[1px] bg-[#C6A15B]" />
                      <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">OUR STORY</span>
                    </div>

                    <h2 className="font-luxury text-3xl sm:text-5xl text-[#171717] font-light leading-tight">
                      A Heritage of Comfort along Tonk Road
                    </h2>

                    <p className="text-[#5C554B] text-sm sm:text-base leading-relaxed">
                      Rooted in Jaipur's vibrant spirit since 2019, Hotel SK Grand represents a journey of thoughtful hospitality, refined spatial comfort, and authentic Rajasthani warmth.
                    </p>

                    <div>
                      <button onClick={() => showPage('about')} className="explore-btn cursor-pointer">
                        VIEW OUR STORY →
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4. ROOMS PREVIEW */}
              <div className="space-y-8 relative">
                <span className="section-number top-0 right-4">02</span>
                <div className="text-center space-y-2 z-10 relative" data-reveal="fade-up">
                  <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">ACCOMMODATIONS</span>
                  <h2 className="font-luxury text-4xl sm:text-5xl text-[#171717] font-light">Rooms & Suites</h2>
                  <p className="text-sm text-[#6B6256]">30 air-conditioned rooms across four luxury categories.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Deluxe Room */}
                  <div className="preview-card bg-white border border-[#C6A15B]/25 p-6 space-y-4 shadow-sm flex flex-col justify-between cursor-pointer" data-reveal="scale-up" onClick={() => showPage('room-detail', 'deluxe')}>
                    <div className="space-y-3">
                      <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                        <img src={ROOMS_DATA['deluxe'].image} alt="Deluxe Room" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 01</span>
                      <h3 className="font-luxury text-2xl text-[#171717]">Deluxe Room</h3>
                      <p className="text-xs text-[#5C554B] leading-relaxed">King bed · AC · LED TV · Minibar · Soundproofed</p>
                    </div>
                    <button className="explore-btn text-[10px] py-2 px-4 cursor-pointer mt-4">EXPLORE →</button>
                  </div>

                  {/* Super Deluxe Room */}
                  <div className="preview-card bg-white border border-[#C6A15B]/25 p-6 space-y-4 shadow-sm flex flex-col justify-between cursor-pointer" data-reveal="scale-up" onClick={() => showPage('room-detail', 'super-deluxe')}>
                    <div className="space-y-3">
                      <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                        <img src={ROOMS_DATA['super-deluxe'].image} alt="Super Deluxe Room" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 02</span>
                      <h3 className="font-luxury text-2xl text-[#171717]">Super Deluxe Room</h3>
                      <p className="text-xs text-[#5C554B] leading-relaxed">All Deluxe + Bathtub · City View · Hair Dryer</p>
                    </div>
                    <button className="explore-btn text-[10px] py-2 px-4 cursor-pointer mt-4">EXPLORE →</button>
                  </div>

                  {/* Suite Room */}
                  <div className="preview-card bg-white border border-[#C6A15B]/25 p-6 space-y-4 shadow-sm flex flex-col justify-between cursor-pointer" data-reveal="scale-up" onClick={() => showPage('room-detail', 'suite')}>
                    <div className="space-y-3">
                      <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                        <img src={ROOMS_DATA['suite'].image} alt="Suite Room" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 03</span>
                      <h3 className="font-luxury text-2xl text-[#171717]">Suite Room</h3>
                      <p className="text-xs text-[#5C554B] leading-relaxed">Largest Space · Panoramic Jaipur Views · VIP Setup</p>
                    </div>
                    <button className="explore-btn text-[10px] py-2 px-4 cursor-pointer mt-4">EXPLORE →</button>
                  </div>

                  {/* Family Room */}
                  <div className="preview-card bg-white border border-[#C6A15B]/25 p-6 space-y-4 shadow-sm flex flex-col justify-between cursor-pointer" data-reveal="scale-up" onClick={() => showPage('room-detail', 'family')}>
                    <div className="space-y-3">
                      <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                        <img src={ROOMS_DATA['family'].image} alt="Family Room" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 04</span>
                      <h3 className="font-luxury text-2xl text-[#171717]">Family Room</h3>
                      <p className="text-xs text-[#5C554B] leading-relaxed">Multi-bed Layout · Family Comfort · Extra Dimensions</p>
                    </div>
                    <button className="explore-btn text-[10px] py-2 px-4 cursor-pointer mt-4">EXPLORE →</button>
                  </div>
                </div>

                <div className="text-center pt-4" data-reveal="fade-up">
                  <button onClick={() => showPage('rooms')} className="explore-btn cursor-pointer">
                    EXPLORE ROOMS →
                  </button>
                </div>
              </div>

              {/* 5. AMENITIES PREVIEW */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 text-center space-y-6 relative overflow-hidden shadow-sm" data-reveal="clip-reveal">
                <span className="section-number top-2 right-4">03</span>
                <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">CONVENIENCE</span>
                <h2 className="font-luxury text-4xl text-[#171717]">Everything You Need</h2>
                <p className="text-sm tracking-[0.2em] uppercase text-[#A9823F] font-semibold max-w-2xl mx-auto leading-loose">
                  WiFi &nbsp;·&nbsp; Parking &nbsp;·&nbsp; Restaurant &nbsp;·&nbsp; Banquet &nbsp;·&nbsp; Business Center &nbsp;·&nbsp; 24/7 Desk
                </p>
                <div>
                  <button onClick={() => showPage('amenities')} className="explore-btn cursor-pointer">
                    VIEW ALL AMENITIES →
                  </button>
                </div>
              </div>

              {/* 6. GALLERY PREVIEW */}
              <div className="space-y-8 text-center" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">VISUAL TOUR</span>
                <h2 className="font-luxury text-4xl sm:text-5xl text-[#171717] font-light">A Glimpse Inside</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {GALLERY_IMAGES.slice(0, 4).map((img) => (
                    <div key={img.id} className="gallery-item aspect-square bg-[#F2ECDE] border border-[#C6A15B]/20 overflow-hidden relative image-hover-wrap cursor-pointer shadow-sm" onClick={() => showPage('gallery')} data-reveal="scale-up">
                      <img src={img.src} alt={img.title} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
                <div>
                  <button onClick={() => showPage('gallery')} className="explore-btn cursor-pointer">
                    VIEW FULL GALLERY →
                  </button>
                </div>
              </div>

              {/* 7. DINING PREVIEW */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center bg-white border border-[#C6A15B]/25 p-8 sm:p-12 relative overflow-hidden shadow-sm">
                <span className="section-number top-2 right-4">04</span>
                <div className="space-y-6 z-10" data-reveal="slide-left">
                  <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">RESTAURANT & BAR</span>
                  <h2 className="font-luxury text-4xl sm:text-5xl text-[#171717] font-light">Dining</h2>
                  <p className="text-[#5C554B] text-base leading-relaxed">
                    Multi-cuisine restaurant. Continental breakfast served 7:30–10 AM daily. Enjoy delicious local and international food.
                  </p>
                  <button onClick={() => showPage('dining')} className="explore-btn cursor-pointer">
                    EXPLORE DINING →
                  </button>
                </div>
                <div className="aspect-[4/3] overflow-hidden bg-[#F2ECDE] border border-[#C6A15B]/20 image-hover-wrap z-10" data-reveal="slide-right">
                  <img 
                    src="https://cdn.phototourl.com/free/2026-09-04-ce3a7f52-c84a-437a-b8ab-52b43ea6e02d.jpg" 
                    alt="Dining Preview"
                    className="w-full h-full object-cover" 
                  />
                </div>
              </div>

              {/* 8. BANQUET HALL SECTION */}
              <div id="banquet-hall-section" className="scroll-mt-28 bg-white border border-[#C6A15B]/25 p-8 sm:p-14 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                <span className="section-number top-2 right-4">BANQUET</span>
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center z-10 relative">
                  
                  {/* LEFT SIDE: DUAL BANQUET IMAGES */}
                  <div className="lg:col-span-7 space-y-4" data-reveal="slide-left">
                    <div className="overflow-hidden relative group aspect-[16/10] bg-[#F2ECDE] border border-[#C6A15B]/25">
                      <img 
                        src="https://cdn.phototourl.com/free/2026-09-04-7ccd586e-bb4f-4f4d-b25c-506d3941592a.jpg" 
                        alt="Hotel SK Grand Grand Banquet Hall - View 1" 
                        className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                      />
                      <div className="absolute bottom-4 left-4 z-10">
                        <span className="bg-white/95 border border-[#C6A15B]/40 text-[#171717] text-[11px] uppercase tracking-[0.2em] px-4 py-2 font-semibold backdrop-blur-md shadow-md">
                          VIEW 1 · STAGE & CELEBRATION
                        </span>
                      </div>
                    </div>

                    <div className="overflow-hidden relative group aspect-[21/9] bg-[#F2ECDE] border border-[#C6A15B]/25">
                      <img 
                        src="https://cdn.phototourl.com/free/2026-09-04-df86f18c-d9cb-4aad-92fe-1e99862c97c2.jpg" 
                        alt="Hotel SK Grand Banquet Hall - View 2" 
                        className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                      />
                      <div className="absolute bottom-3 left-4 z-10">
                        <span className="bg-white/95 border border-[#C6A15B]/40 text-[#171717] text-[10px] uppercase tracking-[0.2em] px-3 py-1.5 font-semibold backdrop-blur-md shadow-md">
                          VIEW 2 · EVENT SEATING & HALL LAYOUT
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* RIGHT SIDE: CONTENT & HIGHLIGHTS */}
                  <div className="lg:col-span-5 space-y-6" data-reveal="slide-right">
                    <div className="inline-flex items-center space-x-3">
                      <span className="w-8 h-[1px] bg-[#C6A15B]" />
                      <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">EVENT SPACE & CELEBRATIONS</span>
                    </div>

                    <h2 className="font-luxury text-3xl sm:text-5xl text-[#171717] font-light leading-tight">
                      Celebrate Your Special Moments
                    </h2>

                    <p className="text-[#5C554B] text-sm sm:text-base leading-relaxed">
                      Make your special occasions memorable with our elegant banquet hall, perfect for weddings, receptions, engagements, birthdays, parties and corporate events.
                    </p>

                    {/* EVENT HIGHLIGHTS */}
                    <div className="space-y-3 pt-2">
                      <span className="text-[11px] uppercase tracking-[0.2em] text-[#C6A15B] font-semibold block">IDEAL FOR</span>
                      <div className="flex flex-wrap gap-2">
                        {[
                          'Weddings & Receptions',
                          'Engagements & Parties',
                          'Birthday Celebrations',
                          'Corporate Events',
                          'Family Functions'
                        ].map((item, idx) => (
                          <span key={idx} className="bg-[#FAF7F2] border border-[#C6A15B]/30 text-[#171717] text-xs px-3 py-1.5 font-medium">
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* THREE CTA BUTTONS */}
                    <div className="flex flex-wrap items-center gap-3 pt-4">
                      <button onClick={() => openBooking('banquet')} className="hero-cta text-xs py-3.5 px-6 cursor-pointer">
                        BOOK BANQUET HALL →
                      </button>
                      <button onClick={() => showPage('banquet')} className="border border-[#C6A15B] text-[#171717] hover:bg-[#C6A15B] hover:text-white text-xs py-3.5 px-5 transition-colors cursor-pointer uppercase tracking-widest font-semibold">
                        VIEW DETAILS
                      </button>
                      <a 
                        href="https://wa.me/919829063140?text=Hello%20Hotel%20SK%20Grand,%20I%20would%20like%20to%20enquire%20about%20booking%20the%20Banquet%20Hall.%20Please%20share%20the%20availability%20and%20details." 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-emerald-700 hover:bg-emerald-800 text-white border border-emerald-500/40 font-medium text-xs tracking-widest uppercase py-3.5 px-5 transition-all duration-300 inline-flex items-center space-x-2 cursor-pointer shadow-md"
                      >
                        <MessageCircle size={16} />
                        <span>WHATSAPP</span>
                      </a>
                    </div>

                  </div>

                </div>
              </div>

              {/* 8. WHY SK GRAND */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 text-center space-y-8 shadow-sm" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">OUR STANDARDS</span>
                <h2 className="font-luxury text-4xl text-[#171717]">Why Choose SK Grand</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
                  <div className="amenity-card bg-[#FAF7F2] border border-[#C6A15B]/25 p-6 space-y-2" data-reveal="scale-up">
                    <h3 className="font-luxury text-xl text-[#171717]">Prime Location</h3>
                    <p className="text-xs text-[#5C554B]">Situated directly on Tonk Road with quick airport & JECC access.</p>
                  </div>
                  <div className="amenity-card bg-[#FAF7F2] border border-[#C6A15B]/25 p-6 space-y-2" data-reveal="scale-up">
                    <h3 className="font-luxury text-xl text-[#171717]">790+ Happy Guests</h3>
                    <p className="text-xs text-[#5C554B]">Consistently rated 4.1/5 for cleanliness and warm hospitality.</p>
                  </div>
                  <div className="amenity-card bg-[#FAF7F2] border border-[#C6A15B]/25 p-6 space-y-2" data-reveal="scale-up">
                    <h3 className="font-luxury text-xl text-[#171717]">24-Hour Service</h3>
                    <p className="text-xs text-[#5C554B]">Round-the-clock front desk, security, and room service.</p>
                  </div>
                  <div className="amenity-card bg-[#FAF7F2] border border-[#C6A15B]/25 p-6 space-y-2" data-reveal="scale-up">
                    <h3 className="font-luxury text-xl text-[#171717]">Free Parking & WiFi</h3>
                    <p className="text-xs text-[#5C554B]">Complimentary self-parking and high-speed internet.</p>
                  </div>
                </div>
              </div>

              {/* 9. REVIEWS PREVIEW */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 text-center space-y-8 shadow-sm" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">GUEST FEEDBACK</span>
                <h2 className="font-luxury text-4xl text-[#171717]">What Guests Say</h2>
                <div className="inline-block bg-[#FAF7F2] border border-[#C6A15B]/30 px-6 py-2.5 text-xs uppercase tracking-widest text-[#A9823F] font-semibold">
                  ★ {reviewsSummary.averageRating} / 5 · {reviewsSummary.totalReviews} Verified Public Reviews
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left max-w-5xl mx-auto">
                  {approvedReviews.slice(0, 3).map((rev) => (
                    <div key={rev.id} className="bg-[#FAF7F2] border border-[#C6A15B]/25 p-6 space-y-3 flex flex-col justify-between shadow-xs hover:border-[#C6A15B]/50 transition-colors">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1 text-[#C6A15B]">
                            {[1, 2, 3, 4, 5].map((s) => (
                              <Star
                                key={s}
                                size={14}
                                fill={s <= rev.rating ? '#C6A15B' : 'transparent'}
                                className={s <= rev.rating ? 'text-[#C6A15B]' : 'text-gray-300'}
                              />
                            ))}
                          </div>
                          {rev.stayType && (
                            <span className="text-[9px] uppercase tracking-widest text-[#C6A15B] font-semibold bg-white border border-[#C6A15B]/30 px-2 py-0.5">
                              {rev.stayType}
                            </span>
                          )}
                        </div>
                        <h3 className="font-luxury text-lg text-[#171717]">{rev.title}</h3>
                        <p className="text-xs text-[#5C554B] italic leading-relaxed font-light">"{rev.message}"</p>
                      </div>
                      <div className="pt-3 border-t border-[#C6A15B]/15 flex items-center justify-between text-[11px] text-[#5C554B]">
                        <span className="font-semibold text-[#171717]">— {rev.name}</span>
                        <span className="text-emerald-700 font-medium text-[10px] flex items-center space-x-1">
                          <CheckCircle2 size={12} />
                          <span>Verified</span>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
                  <button onClick={() => showPage('reviews')} className="explore-btn cursor-pointer">
                    READ MORE REVIEWS →
                  </button>
                  <button 
                    onClick={() => setIsReviewModalOpen(true)} 
                    className="border border-[#C6A15B] text-[#171717] hover:bg-[#C6A15B] hover:text-white text-xs font-semibold py-3.5 px-6 uppercase tracking-widest transition-all cursor-pointer"
                  >
                    WRITE A REVIEW
                  </button>
                </div>
              </div>

              {/* 10. LOCATION PREVIEW */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 text-center space-y-6 shadow-sm" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold">HERITAGE BASE</span>
                <h2 className="font-luxury text-4xl text-[#171717]">Find Us</h2>
                <p className="text-sm text-[#5C554B] max-w-xl mx-auto">
                  Tonk Road, Sanganer, Jaipur — 5 km from Jaipur International Airport & 1 km from JECC.
                </p>
                <div>
                  <button onClick={() => showPage('location')} className="explore-btn cursor-pointer">
                    GET DIRECTIONS →
                  </button>
                </div>
              </div>

              {/* 11. BOOKING CTA PREVIEW */}
              <div className="bg-white border border-[#C6A15B]/30 p-12 text-center space-y-6 shadow-sm" data-reveal="scale-up">
                <h2 className="font-luxury text-5xl text-[#171717]">Ready to Stay?</h2>
                <p className="text-sm text-[#5C554B] max-w-md mx-auto">
                  Check availability and book your room direct for best rates.
                </p>
                <div>
                  <button onClick={() => showPage('booking')} className="explore-btn cursor-pointer">
                    BOOK NOW →
                  </button>
                </div>
              </div>

            </div>

          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 2: ROOMS (#page-rooms)                */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'rooms' && (
          <section id="page-rooms" className="w-full pt-20">
            {/* Mini Hero */}
            <div className="h-[40vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">ROOMS & SUITES</span>
              <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">Your Room in Jaipur</h1>
              <p className="text-xs sm:text-sm text-[#5C554B] max-w-lg mt-3">
                Every room at SK Grand is built around comfort — from our Deluxe and Super Deluxe rooms to our Family Rooms and top-floor Suites.
              </p>
            </div>

            {/* 4 ROOM CARDS */}
            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                
                {/* DELUXE ROOM */}
                <div className="tilt-card room-card bg-white border border-[#C6A15B]/25 p-6 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                  <span className="section-number top-2 right-4">01</span>
                  <div className="space-y-4 z-10">
                    <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                      <img src={ROOMS_DATA['deluxe'].image} alt="Deluxe Room" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 01</span>
                    <h2 className="font-luxury text-2xl text-[#171717]">Deluxe Room</h2>
                    <ul className="space-y-2 text-xs text-[#5C554B]">
                      <li>• King-sized Bed</li>
                      <li>• Air Conditioning & LED TV</li>
                      <li>• Minibar & Tea/Coffee Maker</li>
                      <li>• Soundproofed Windows</li>
                    </ul>
                  </div>
                  <button 
                    onClick={() => showPage('room-detail', 'deluxe')}
                    className="explore-btn w-full text-center cursor-pointer z-10 mt-4"
                  >
                    VIEW DETAILS →
                  </button>
                </div>

                {/* SUPER DELUXE ROOM */}
                <div className="tilt-card room-card bg-white border border-[#C6A15B]/25 p-6 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                  <span className="section-number top-2 right-4">02</span>
                  <div className="space-y-4 z-10">
                    <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                      <img src={ROOMS_DATA['super-deluxe'].image} alt="Super Deluxe Room" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 02</span>
                    <h2 className="font-luxury text-2xl text-[#171717]">Super Deluxe Room</h2>
                    <ul className="space-y-2 text-xs text-[#5C554B]">
                      <li>• All Deluxe Amenities</li>
                      <li>• Bathtub (Select Rooms)</li>
                      <li>• 3rd Floor City View</li>
                      <li>• Hair Dryer & Bidet</li>
                    </ul>
                  </div>
                  <button 
                    onClick={() => showPage('room-detail', 'super-deluxe')}
                    className="explore-btn w-full text-center cursor-pointer z-10 mt-4"
                  >
                    VIEW DETAILS →
                  </button>
                </div>

                {/* SUITE ROOM */}
                <div className="tilt-card room-card bg-white border border-[#C6A15B]/25 p-6 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                  <span className="section-number top-2 right-4">03</span>
                  <div className="space-y-4 z-10">
                    <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                      <img src={ROOMS_DATA['suite'].image} alt="Suite Room" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 03</span>
                    <h2 className="font-luxury text-2xl text-[#171717]">Suite Room</h2>
                    <ul className="space-y-2 text-xs text-[#5C554B]">
                      <li>• Largest Floor Plan</li>
                      <li>• Panoramic Jaipur Vistas</li>
                      <li>• VIP Luxury Furnishings</li>
                      <li>• Express Room Service</li>
                    </ul>
                  </div>
                  <button 
                    onClick={() => showPage('room-detail', 'suite')}
                    className="explore-btn w-full text-center cursor-pointer z-10 mt-4"
                  >
                    VIEW DETAILS →
                  </button>
                </div>

                {/* FAMILY ROOM */}
                <div className="tilt-card room-card bg-white border border-[#C6A15B]/25 p-6 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-sm" data-reveal="fade-up">
                  <span className="section-number top-2 right-4">04</span>
                  <div className="space-y-4 z-10">
                    <div className="image-hover-wrap aspect-[4/3] bg-[#F2ECDE] overflow-hidden">
                      <img src={ROOMS_DATA['family'].image} alt="Family Room" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[10px] uppercase tracking-widest text-[#C6A15B] font-semibold block">CATEGORY 04</span>
                    <h2 className="font-luxury text-2xl text-[#171717]">Family Room</h2>
                    <ul className="space-y-2 text-xs text-[#5C554B]">
                      <li>• Multiple Bed Layouts</li>
                      <li>• Spacious Living Nook</li>
                      <li>• Family Comfort & Space</li>
                      <li>• Hot Geyser & Vanity</li>
                    </ul>
                  </div>
                  <button 
                    onClick={() => showPage('room-detail', 'family')}
                    className="explore-btn w-full text-center cursor-pointer z-10 mt-4"
                  >
                    VIEW DETAILS →
                  </button>
                </div>

              </div>

              <div className="bg-white border border-[#C6A15B]/25 p-8 text-center space-y-4 shadow-sm" data-reveal="scale-up">
                <h3 className="font-luxury text-3xl text-[#171717]">Check Room Availability</h3>
                <p className="text-xs text-[#5C554B]">Direct reservations receive priority room allocation & best rates.</p>
                <button onClick={() => showPage('booking')} className="explore-btn cursor-pointer">
                  CHECK AVAILABILITY →
                </button>
              </div>
            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 3: ROOM DETAIL (#page-room-detail)    */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'room-detail' && (
          <section id="page-room-detail" className="w-full pt-20">
            {/* Room Hero with Low Opacity Room Image Layer */}
            <div className="relative h-[42vh] min-h-[280px] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20 overflow-hidden">
              {/* Dynamic Room Image Background Layer with Low Opacity */}
              <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
                <img 
                  src={activeRoomData.image} 
                  alt={activeRoomData.name} 
                  className="w-full h-full object-cover object-center opacity-20 filter saturate-[0.6] contrast-[1.05] scale-105 transition-all duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-b from-[#FAF7F2]/85 via-[#FAF7F2]/65 to-[#FAF7F2]/95" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,#FAF7F2_90%)] opacity-80" />
              </div>

              <div className="relative z-10 space-y-2 max-w-2xl" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">{activeRoomData.category}</span>
                <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">{activeRoomData.name}</h1>
                <p className="text-xs sm:text-sm text-[#5C554B] max-w-lg mt-3 font-light leading-relaxed">{activeRoomData.tagline}</p>
              </div>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              
              {/* Description */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-4 shadow-sm" data-reveal="fade-up">
                <h2 className="font-luxury text-3xl text-[#171717]">Room Overview</h2>
                <p className="text-sm text-[#5C554B] leading-relaxed">{activeRoomData.description}</p>
                <p className="text-xs text-[#A9823F] font-semibold pt-2">Note: {activeRoomData.priceNote}</p>
              </div>

              {/* Full Facilities List */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-6 shadow-sm" data-reveal="slide-left">
                <h2 className="font-luxury text-3xl text-[#171717]">Full Room Facilities</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-[#171717]">
                  {activeRoomData.fullFacilities.map((fac, idx) => (
                    <div key={idx} className="flex items-center space-x-3">
                      <Check size={16} className="text-[#C6A15B] shrink-0" />
                      <span>{fac}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Photo Gallery of Room (if available) */}
              {activeRoomData.gallery && activeRoomData.gallery.length > 0 && (
                <div className="space-y-6" data-reveal="fade-up">
                  <h2 className="font-luxury text-3xl text-[#171717]">Room Gallery</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    {activeRoomData.gallery.map((gImg, idx) => (
                      <div key={idx} className="aspect-[4/3] bg-[#F2ECDE] border border-[#C6A15B]/20 overflow-hidden image-hover-wrap shadow-sm" data-reveal="scale-up">
                        <img src={gImg} alt={`${activeRoomData.name} photo ${idx + 1}`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Booking Action */}
              <div className="bg-white border border-[#C6A15B]/30 p-8 sm:p-12 text-center space-y-6 shadow-sm" data-reveal="scale-up">
                <h3 className="font-luxury text-4xl text-[#171717]">Reserve {activeRoomData.name}</h3>
                <p className="text-xs text-[#5C554B]">Rates vary by date — check availability for direct booking.</p>
                <div className="flex justify-center gap-4 flex-wrap">
                  <button onClick={() => showPage('booking', selectedRoomKey)} className="explore-btn cursor-pointer">
                    BOOK THIS ROOM →
                  </button>
                  <button onClick={() => showPage('rooms')} className="border border-[#C6A15B]/40 text-[#171717] px-6 py-3 text-xs tracking-widest uppercase hover:bg-[#C6A15B] hover:text-white cursor-pointer font-semibold transition-colors">
                    ← BACK TO ROOMS
                  </button>
                </div>
              </div>

            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 4: DINING (#page-dining)              */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'dining' && (
          <section id="page-dining" className="w-full pt-20">
            {/* 13. Dining Hero with Light Sweep */}
            <div className="relative h-[50vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20 overflow-hidden">
              <div className={`light-sweep ${diningSweepActive ? 'active' : ''}`} />
              <img src="https://cdn.phototourl.com/free/2026-09-04-ce3a7f52-c84a-437a-b8ab-52b43ea6e02d.jpg" alt="Dining" className="absolute inset-0 w-full h-full object-cover opacity-35" />
              <div className="absolute inset-0 bg-[#171717]/40" />
              <div className="relative z-10 space-y-3">
                <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">RESTAURANT & BAR</span>
                <h1 className="font-luxury text-4xl sm:text-7xl text-white font-light">Taste the Pink City</h1>
              </div>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              
              {/* Menu Details */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-8 max-w-4xl mx-auto text-center shadow-sm" data-reveal="fade-up">
                <div className="aspect-[16/9] w-full overflow-hidden bg-[#F2ECDE] border border-[#C6A15B]/20 image-hover-wrap mb-4">
                  <img 
                    src="https://cdn.phototourl.com/free/2026-09-04-ce3a7f52-c84a-437a-b8ab-52b43ea6e02d.jpg" 
                    alt="Hotel SK Grand Dining Experience" 
                    className="w-full h-full object-cover transition-transform duration-700 ease-out hover:scale-105" 
                  />
                </div>
                <Utensils size={36} className="mx-auto text-[#C6A15B]" />
                <h2 className="font-luxury text-4xl text-[#171717]">Culinary Experience</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-left text-sm">
                  <div className="bg-[#FAF7F2] p-6 border border-[#C6A15B]/25 space-y-2" data-reveal="slide-left">
                    <h3 className="font-luxury text-2xl text-[#171717]">Breakfast Buffet</h3>
                    <p className="text-xs text-[#A9823F] font-semibold">Daily: 7:30 AM – 10:00 AM</p>
                    <p className="text-xs text-[#5C554B]">Continental spreads, fresh juices, tea, coffee, and local hot dishes.</p>
                  </div>

                  <div className="bg-[#FAF7F2] p-6 border border-[#C6A15B]/25 space-y-2" data-reveal="slide-right">
                    <h3 className="font-luxury text-2xl text-[#171717]">Dinner & Room Service</h3>
                    <p className="text-xs text-[#A9823F] font-semibold">24-Hour Room Service</p>
                    <p className="text-xs text-[#5C554B]">Multi-cuisine menu featuring traditional Rajasthani and Indian classics.</p>
                  </div>
                </div>
              </div>

              {/* Nearby Dining */}
              <div className="space-y-6 max-w-4xl mx-auto" data-reveal="fade-up">
                <h3 className="font-luxury text-3xl text-[#171717] text-center">Nearby Dining Recommendations</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="bg-white border border-[#C6A15B]/25 p-6 space-y-1 shadow-sm" data-reveal="scale-up">
                    <h4 className="font-luxury text-xl text-[#171717]">Dhani Café & Restaurant</h4>
                    <span className="text-[11px] text-[#A9823F] font-semibold block">1 km from hotel</span>
                    <p className="text-xs text-[#5C554B]">Rajasthani Thali & Indian regional cuisine.</p>
                  </div>
                  <div className="bg-white border border-[#C6A15B]/25 p-6 space-y-1 shadow-sm" data-reveal="scale-up">
                    <h4 className="font-luxury text-xl text-[#171717]">Agra Burger Centre</h4>
                    <span className="text-[11px] text-[#A9823F] font-semibold block">270 m from hotel</span>
                    <p className="text-xs text-[#5C554B]">Quick street snacks and local fast food.</p>
                  </div>
                  <div className="bg-white border border-[#C6A15B]/25 p-6 space-y-1 shadow-sm" data-reveal="scale-up">
                    <h4 className="font-luxury text-xl text-[#171717]">The Caveland Restaurant</h4>
                    <span className="text-[11px] text-[#A9823F] font-semibold block">270 m from hotel</span>
                    <p className="text-xs text-[#5C554B]">Theme restaurant serving multi-cuisine dishes.</p>
                  </div>
                  <div className="bg-white border border-[#C6A15B]/25 p-6 space-y-1 shadow-sm" data-reveal="scale-up">
                    <h4 className="font-luxury text-xl text-[#171717]">The Sandwich Store</h4>
                    <span className="text-[11px] text-[#A9823F] font-semibold block">5.4 km from hotel</span>
                    <p className="text-xs text-[#5C554B]">Gourmet snacks and artisan beverages.</p>
                  </div>
                </div>
              </div>

            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 5: BANQUET HALL (#page-banquet)        */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'banquet' && (
          <section id="page-banquet" className="w-full pt-20">
            {/* 12. Banquet Curtain Hero */}
            <div className="banquet-hero h-[50vh] flex flex-col justify-center items-center text-center bg-[#FAF7F2] border-b border-[#C6A15B]/20 relative overflow-hidden">
              <div className={`banquet-curtain-l ${banquetCurtainOpen ? 'open' : ''}`} />
              <div className={`banquet-curtain-r ${banquetCurtainOpen ? 'open' : ''}`} />
              
              <img src="https://cdn.phototourl.com/free/2026-09-04-7ccd586e-bb4f-4f4d-b25c-506d3941592a.jpg" alt="Banquet Hall" className="absolute inset-0 w-full h-full object-cover opacity-80" />
              <div className="absolute inset-0 bg-[#171717]/40 z-0" />
              <div className="relative z-10 space-y-3 px-6">
                <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">EVENTS & CONFERENCES</span>
                <h1 className="font-luxury text-4xl sm:text-7xl text-white font-light">Banquet Hall</h1>
              </div>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-8 max-w-5xl mx-auto shadow-sm" data-reveal="fade-up">
                
                {/* DUAL BANQUET HALL GALLERY DISPLAY */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="aspect-[16/10] w-full overflow-hidden bg-[#F2ECDE] border border-[#C6A15B]/20 image-hover-wrap relative group">
                      <img 
                        src="https://cdn.phototourl.com/free/2026-09-04-7ccd586e-bb4f-4f4d-b25c-506d3941592a.jpg" 
                        alt="Hotel SK Grand Banquet Hall - View 1" 
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105" 
                      />
                      <span className="absolute bottom-3 left-3 bg-[#171717]/85 backdrop-blur-sm text-[#C6A15B] text-[10px] uppercase tracking-[0.2em] px-3 py-1 font-semibold border border-[#C6A15B]/30">
                        View 1 · Grand Stage & Celebration
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="aspect-[16/10] w-full overflow-hidden bg-[#F2ECDE] border border-[#C6A15B]/20 image-hover-wrap relative group">
                      <img 
                        src="https://cdn.phototourl.com/free/2026-09-04-df86f18c-d9cb-4aad-92fe-1e99862c97c2.jpg" 
                        alt="Hotel SK Grand Banquet Hall - View 2" 
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105" 
                      />
                      <span className="absolute bottom-3 left-3 bg-[#171717]/85 backdrop-blur-sm text-[#C6A15B] text-[10px] uppercase tracking-[0.2em] px-3 py-1 font-semibold border border-[#C6A15B]/30">
                        View 2 · Event Hall & Seating Layout
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-center space-y-4 pt-2">
                  <Building2 size={36} className="mx-auto text-[#C6A15B]" />
                  <h2 className="font-luxury text-4xl text-[#171717]">Conference & Event Facilities</h2>
                  <p className="text-sm text-[#5C554B] leading-relaxed max-w-2xl mx-auto">
                    Ideal for corporate meetings, private family functions, weddings, engagements, and seminars on Tonk Road, Jaipur.
                  </p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#171717] text-left pt-4">
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>Business Center Facilities</span></div>
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>Video Conferencing Ready</span></div>
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>Meeting & Seminar Setups</span></div>
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>Multilingual Event Staff</span></div>
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>Photocopying & Printing</span></div>
                  <div className="flex items-center space-x-2"><Check size={14} className="text-[#C6A15B]" /><span>In-house Catering Options</span></div>
                </div>
                <div className="pt-6 flex flex-wrap items-center justify-center gap-4">
                  <button onClick={() => openBooking('banquet')} className="hero-cta text-xs py-3.5 px-6 cursor-pointer font-bold">
                    BOOK BANQUET HALL / ENQUIRE NOW →
                  </button>
                  <a 
                    href="tel:+919829063140"
                    className="border border-[#C6A15B] text-[#171717] px-6 py-3.5 text-xs tracking-widest uppercase hover:bg-[#C6A15B] hover:text-white transition-colors inline-flex items-center space-x-2 cursor-pointer font-semibold"
                  >
                    <Phone size={15} />
                    <span>CALL +91 98290 63140</span>
                  </a>
                  <a 
                    href="https://wa.me/919829063140?text=Hello%20Hotel%20SK%20Grand,%20I%20would%20like%20to%20enquire%20about%20booking%20the%20Banquet%20Hall.%20Please%20share%20the%20availability%20and%20details." 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-emerald-700 hover:bg-emerald-800 text-white border border-emerald-500/40 px-6 py-3.5 text-xs tracking-widest uppercase transition-colors inline-flex items-center space-x-2 cursor-pointer font-medium shadow-md"
                  >
                    <MessageCircle size={15} />
                    <span>WHATSAPP ENQUIRY</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 6: AMENITIES (#page-amenities)        */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'amenities' && (
          <section id="page-amenities" className="w-full pt-20">
            <div className="h-[40vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">FULL FACILITIES</span>
              <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">Everything You Need</h1>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              
              {/* In-Room */}
              <div className="space-y-6" data-reveal="fade-up">
                <h2 className="font-luxury text-3xl text-[#171717]">In-Room Comforts</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                  {[
                    'WiFi', 'Air Conditioning', 'LED TV', 'Minibar', 
                    'Geyser Hot Water', 'Electronic Safe', 'Keycard Entry', 
                    'Ironing Facilities', 'Balcony (Select)', 'Hair Dryer (Select)'
                  ].map((item, idx) => (
                    <div key={idx} className="amenity-card bg-white border border-[#C6A15B]/25 p-6 text-center space-y-2 shadow-sm" data-reveal="scale-up">
                      <Sparkles size={20} className="mx-auto text-[#C6A15B]" />
                      <span className="text-xs text-[#171717] font-medium block">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Hotel Services */}
              <div className="space-y-6" data-reveal="fade-up">
                <h2 className="font-luxury text-3xl text-[#171717]">Hotel Facilities & Services</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[
                    { name: 'Free Self Parking', desc: 'Secure parking on site for hotel guests' },
                    { name: 'Power Backup', desc: 'Continuous electrical supply throughout' },
                    { name: 'CCTV Security', desc: 'Round-the-clock security monitoring' },
                    { name: '24/7 Front Desk', desc: 'Always available check-in & guest service' },
                    { name: 'Housekeeping & Dry Cleaning', desc: 'Daily room upkeep & laundry services' },
                    { name: 'On-site Restaurant', desc: 'Continental breakfast & multi-cuisine dining' },
                    { name: '24-Hour Room Service', desc: 'In-room dining served straight to you' },
                    { name: 'Banquet & Business Center', desc: 'Meeting room & event arrangements' },
                    { name: 'Airport Pickup & Drop', desc: 'Paid shuttle services on demand' },
                  ].map((item, idx) => (
                    <div key={idx} className="amenity-card bg-white border border-[#C6A15B]/25 p-6 space-y-2 shadow-sm" data-reveal="scale-up">
                      <h3 className="font-luxury text-xl text-[#171717]">{item.name}</h3>
                      <p className="text-xs text-[#5C554B]">{item.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 7: GALLERY (#page-gallery)            */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'gallery' && (
          <section id="page-gallery" className="w-full pt-20">
            <div className="h-[40vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">PHOTOGRAPHY</span>
              <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">A Visual Tour</h1>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-12">
              
              {/* Category Filter */}
              <div className="flex flex-wrap justify-center gap-3" data-reveal="fade-up">
                {['All', 'Rooms', 'Restaurant', 'Banquet', 'Exterior', 'Lobby', 'Hotel'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setGalleryFilter(cat)}
                    className={`px-5 py-2 text-xs tracking-widest uppercase transition-colors cursor-pointer font-semibold ${
                      galleryFilter === cat
                        ? 'bg-[#C6A15B] text-white shadow-md'
                        : 'border border-[#C6A15B]/30 text-[#171717] hover:border-[#C6A15B] hover:bg-[#FAF7F2]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Photo Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {GALLERY_IMAGES
                  .filter((img) => galleryFilter === 'All' || img.category === galleryFilter)
                  .map((img) => (
                    <div 
                      key={img.id} 
                      className="gallery-item bg-white border border-[#C6A15B]/25 overflow-hidden group cursor-pointer relative aspect-[4/3] image-hover-wrap shadow-sm"
                      onClick={() => setActiveLightboxImg(img.src)}
                      data-reveal="scale-up"
                    >
                      <img src={img.src} alt={img.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-[#171717]/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2 z-10">
                        <Eye size={20} className="text-white" />
                        <span className="text-xs text-white uppercase tracking-widest font-semibold">Enlarge</span>
                      </div>
                    </div>
                  ))}
              </div>

            </div>

            {/* Lightbox Modal */}
            {activeLightboxImg && (
              <div className="lightbox-modal" onClick={() => setActiveLightboxImg(null)}>
                <button className="absolute top-8 right-8 text-[#F5F0E8] cursor-pointer" onClick={() => setActiveLightboxImg(null)}>
                  <X size={32} />
                </button>
                <img src={activeLightboxImg} alt="Enlarged view" className="max-w-full max-h-[85vh] object-contain border border-[#B8875A]/40" />
              </div>
            )}

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 8: OUR STORY DEDICATED PAGE (#page-about / /our-story) */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'about' && (
          <section id="page-about" className="w-full pt-16">
            
            {/* 1. CINEMATIC TOP HERO — SAME HOTEL IMAGE */}
            <div className="relative w-full h-[75vh] min-h-[500px] overflow-hidden flex flex-col justify-end p-8 sm:p-16 border-b border-[#C6A15B]/20">
              <img 
                src="https://cdn.phototourl.com/member/2026-09-04-47cfe3a7-3ec0-4bf6-a166-0e483f03f7b1.jpg" 
                alt="Hotel SK Grand Architecture and Hospitality" 
                className="absolute inset-0 w-full h-full object-cover transform scale-105 transition-transform duration-[10000ms] ease-out hover:scale-100"
                style={{ objectPosition: 'center 35%' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#171717] via-[#171717]/40 to-transparent z-10 pointer-events-none" />

              <div className="relative z-20 max-w-4xl space-y-4" data-reveal="fade-up">
                <div className="inline-flex items-center space-x-3">
                  <span className="w-10 h-[1px] bg-[#C6A15B]" />
                  <span className="text-xs uppercase tracking-[0.35em] text-[#C6A15B] font-semibold">OUR STORY</span>
                </div>
                <h1 className="font-luxury text-5xl sm:text-7xl lg:text-8xl text-white font-light leading-none tracking-tight">
                  OUR STORY
                </h1>
                <p className="font-luxury text-xl sm:text-3xl text-white/90 italic font-light tracking-wide max-w-2xl">
                  The story behind Hotel SK Grand
                </p>
              </div>

              <div className="absolute bottom-6 right-8 sm:right-16 z-20 hidden sm:flex items-center space-x-3 opacity-80">
                <span className="text-[10px] uppercase tracking-[0.3em] text-white font-semibold">EXPLORE THE JOURNEY</span>
                <div className="w-12 h-[1px] bg-[#C6A15B]" />
              </div>
            </div>

            {/* 2. STORY CONTENT SECTION — OUR JOURNEY */}
            <div className="max-w-6xl mx-auto px-6 sm:px-12 py-24 space-y-28">
              
              {/* SECTION HEADER */}
              <div className="text-center space-y-4 max-w-3xl mx-auto" data-reveal="fade-up">
                <span className="text-xs uppercase tracking-[0.35em] text-[#C6A15B] font-semibold">HERITAGE & HOSPITALITY</span>
                <h2 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light">OUR JOURNEY</h2>
                <div className="w-16 h-[1px] bg-[#C6A15B]/50 mx-auto mt-4" />
                <p className="text-[#5C554B] text-base sm:text-lg leading-relaxed pt-2">
                  From a quiet vision along Tonk Road to becoming one of Pratap Nagar's most trusted hospitality addresses, Hotel SK Grand was created to offer genuine sanctuary for every guest visiting Jaipur.
                </p>
              </div>

              {/* CHAPTER 1: LOCATION & FOUNDATION */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center" data-reveal="fade-up">
                <div className="lg:col-span-5 space-y-6" data-reveal="slide-left">
                  <div className="space-y-2">
                    <span className="text-[11px] uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">CHAPTER 01</span>
                    <h3 className="font-luxury text-3xl sm:text-4xl text-[#171717] font-light">
                      Rooted on Tonk Road, Connected to Jaipur
                    </h3>
                  </div>
                  <p className="text-[#5C554B] text-sm sm:text-base leading-relaxed">
                    In 2019, Hotel SK Grand opened its doors in Ram Nagar-A, Pratap Nagar—a strategic node along Jaipur’s prominent Tonk Road arterial corridor. Located just 5 km from Jaipur International Airport and minutes away from the Jaipur Exhibition & Convention Centre (JECC), the hotel was established to meet the rising need for serene, dependable, and high-value accommodations.
                  </p>
                  <div className="pt-2 border-l-2 border-[#C6A15B] pl-4 text-xs italic text-[#A9823F] font-semibold">
                    "Positioned where Rajasthan’s royal heritage meets modern industrial and corporate Jaipur."
                  </div>
                </div>

                <div className="lg:col-span-7 bg-white border border-[#C6A15B]/25 p-8 space-y-6 shadow-sm" data-reveal="slide-right">
                  <div className="grid grid-cols-2 gap-6 text-center">
                    <div className="border-r border-[#C6A15B]/20 pr-4">
                      <span className="font-luxury text-4xl sm:text-5xl text-[#C6A15B] block font-light">2019</span>
                      <span className="text-[10px] uppercase tracking-[0.2em] text-[#6B6256] font-semibold mt-1 block">ESTABLISHED</span>
                    </div>
                    <div>
                      <span className="font-luxury text-4xl sm:text-5xl text-[#171717] block font-light">5 km</span>
                      <span className="text-[10px] uppercase tracking-[0.2em] text-[#6B6256] font-semibold mt-1 block">FROM AIRPORT</span>
                    </div>
                  </div>
                  <p className="text-xs text-[#5C554B] leading-relaxed border-t border-[#C6A15B]/20 pt-6 text-center">
                    Whether welcoming international business delegates attending trade expos at JECC or families visiting Chokhi Dhani, SK Grand offers an accessible base without sacrificing quiet comfort.
                  </p>
                </div>
              </div>

              {/* CHAPTER 2: THE PHILOSOPHY OF SANCTUARY */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center" data-reveal="fade-up">
                <div className="lg:col-span-6 bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-6 order-2 lg:order-1 shadow-sm" data-reveal="slide-left">
                  <span className="text-[11px] uppercase tracking-[0.3em] text-[#C6A15B] font-semibold block">CHAPTER 02</span>
                  <h3 className="font-luxury text-3xl sm:text-4xl text-[#171717] font-light">
                    Crafting Peaceful Resting Spaces
                  </h3>
                  <p className="text-[#5C554B] text-sm leading-relaxed">
                    Every element across our 30 air-conditioned guest rooms was chosen with quiet intention. We recognized that traveling can be exhausting, so we prioritized what matters most: double-glazed acoustically soundproofed windows to block traffic noise, supportive mattresses, 24/7 hot showers, and high-speed Wi-Fi.
                  </p>
                  <ul className="space-y-3 text-xs text-[#171717] pt-2">
                    <li className="flex items-center space-x-3">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
                      <span>Double-glazed soundproofed window architecture</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
                      <span>Three distinct room categories tailored for every length of stay</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C6A15B]" />
                      <span>Round-the-clock front desk attentiveness and in-room dining</span>
                    </li>
                  </ul>
                </div>

                <div className="lg:col-span-6 space-y-6 order-1 lg:order-2" data-reveal="slide-right">
                  <div className="overflow-hidden relative group aspect-[16/10] bg-[#F2ECDE] border border-[#C6A15B]/25 shadow-sm">
                    <img 
                      src="https://cdn.phototourl.com/free/2026-09-04-90a0f08a-1405-483e-b0d9-6f0c02faa50a.jpg" 
                      alt="Hotel SK Grand Interior & Sanctuary" 
                      className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-105"
                    />
                  </div>
                  <div className="p-8 bg-white border-l-4 border-[#C6A15B] border border-[#C6A15B]/20 space-y-4 shadow-sm">
                    <p className="font-luxury text-2xl sm:text-3xl text-[#171717] italic font-light leading-snug">
                      "Hospitality is not merely providing a bed—it is creating an atmosphere where body and mind can truly reset."
                    </p>
                    <span className="text-xs uppercase tracking-[0.25em] text-[#C6A15B] font-semibold block">— Hotel SK Grand Management</span>
                  </div>
                </div>
              </div>

              {/* CHAPTER 3: DEDICATION & GUEST TRUST */}
              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-14 text-center space-y-8 shadow-sm" data-reveal="scale-up">
                <span className="text-[11px] uppercase tracking-[0.3em] text-[#C6A15B] font-semibold block">CHAPTER 03</span>
                <h3 className="font-luxury text-3xl sm:text-5xl text-[#171717] font-light max-w-2xl mx-auto">
                  Over 790 Stories of Trust
                </h3>
                <p className="text-[#5C554B] text-sm sm:text-base leading-relaxed max-w-3xl mx-auto">
                  Our proudest milestone is not measured in physical expansion, but in the authentic reviews left by travelers who have called SK Grand home. Holding a 4.1 out of 5 rating across over 790 verified reviews, we continue to refine our service, update our facilities, and welcome every guest with Rajasthan's timeless warmth.
                </p>

                {/* REVIEWS GRID */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left max-w-4xl mx-auto pt-4">
                  <div className="bg-[#FAF7F2] border border-[#C6A15B]/20 p-6 space-y-3">
                    <div className="flex items-center space-x-1 text-[#C6A15B]">
                      {[...Array(5)].map((_, i) => <Star key={i} size={14} className="fill-[#C6A15B]" />)}
                    </div>
                    <p className="text-xs italic text-[#5C554B] leading-relaxed">
                      "Good for business — very good road connectivity on Tonk Road. Hotel MD very helpful and welcoming."
                    </p>
                    <span className="text-[11px] text-[#C6A15B] font-semibold block">— Business Delegate</span>
                  </div>

                  <div className="bg-[#FAF7F2] border border-[#C6A15B]/20 p-6 space-y-3">
                    <div className="flex items-center space-x-1 text-[#C6A15B]">
                      {[...Array(5)].map((_, i) => <Star key={i} size={14} className="fill-[#C6A15B]" />)}
                    </div>
                    <p className="text-xs italic text-[#5C554B] leading-relaxed">
                      "Clean rooms, pleasant atmosphere, peaceful environment. Continental breakfast was great."
                    </p>
                    <span className="text-[11px] text-[#C6A15B] font-semibold block">— Leisure Traveler</span>
                  </div>
                </div>

                <div className="pt-6">
                  <button onClick={() => showPage('booking')} className="hero-cta cursor-pointer">
                    EXPERIENCE OUR HOSPITALITY →
                  </button>
                </div>
              </div>

            </div>

            {/* BACK TO HOME FOOTER LINK */}
            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 9: LOCATION & CONTACT (#page-location) */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'location' && (
          <section id="page-location" className="w-full pt-20">
            <div className="h-[40vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">NAVIGATION & CONTACT</span>
              <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">Find Us</h1>
            </div>

            <div className="max-w-7xl mx-auto px-6 sm:px-12 py-20 space-y-16">
              
              {/* Interactive Map Embed */}
              <div className="bg-white border border-[#C6A15B]/25 overflow-hidden h-[450px] shadow-sm" data-reveal="scale-up">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.123!2d75.7516!3d26.7820!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396dc965782e8fd7%3A0x89c09036f4e8b4a2!2sHOTEL%20SK%20GRAND!5e0!3m2!1sen!2sin!4v1"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  title="Hotel SK Grand Map"
                />
              </div>

              {/* Details & Distances */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-6 shadow-sm" data-reveal="slide-left">
                  <h2 className="font-luxury text-3xl text-[#171717]">Hotel Address</h2>
                  <div className="space-y-4 text-sm text-[#5C554B] leading-relaxed">
                    <p>
                      <strong className="text-[#171717] block mb-1">Hotel SK Grand</strong>
                      Plot No. 1 & 2, Ram Nagar-A,<br />
                      Near Bambala Puliya, Tonk Road,<br />
                      Pratap Nagar, Jaipur — 302033, Rajasthan
                    </p>
                    <p>
                      <strong className="text-[#171717]">Phone / Call:</strong>{' '}
                      <a href="tel:+919829063140" className="text-[#A9823F] hover:underline font-bold">+91 98290 63140</a>
                      <span className="text-[#5C554B]"> &nbsp;|&nbsp; </span>
                      <a href="tel:+919828063140" className="text-[#A9823F] hover:underline font-bold">+91 98280 63140</a>
                    </p>
                    <p>
                      <strong className="text-[#171717]">WhatsApp Booking:</strong>{' '}
                      <a 
                        href="https://wa.me/919829063140?text=Hello%20Hotel%20SK%20Grand,%20I%20would%20like%20to%20enquire%20about%20a%20booking.%20Please%20share%20the%20availability%20and%20details." 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-emerald-600 hover:underline font-bold"
                      >
                        +91 98290 63140
                      </a>
                    </p>
                    <p><strong className="text-[#171717]">Check-in:</strong> 12:00 PM · <strong className="text-[#171717]">Check-out:</strong> 12:00 PM</p>
                  </div>
                  <div>
                    <a 
                      href="https://maps.app.goo.gl/QKX2SHH6N2TyPgiY9" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="explore-btn directions-btn inline-block cursor-pointer"
                    >
                      GET DIRECTIONS ON GOOGLE MAPS →
                    </a>
                  </div>
                </div>

                <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 space-y-6 shadow-sm" data-reveal="slide-right">
                  <h2 className="font-luxury text-3xl text-[#171717]">Key Travel Distances</h2>
                  <div className="space-y-4 text-sm text-[#171717]">
                    <div className="flex justify-between items-center py-3 border-b border-[#C6A15B]/20">
                      <span className="font-medium text-[#171717]">Jaipur International Airport</span>
                      <span className="text-[#A9823F] font-bold text-base">5 km</span>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-[#C6A15B]/20">
                      <span className="font-medium text-[#171717]">Chokhi Dhani</span>
                      <span className="text-[#A9823F] font-bold text-base">2 km</span>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-[#C6A15B]/20">
                      <span className="font-medium text-[#171717]">JECC (Jaipur Exhibition & Convention Centre)</span>
                      <span className="text-[#A9823F] font-bold text-base">1 km</span>
                    </div>
                    <div className="flex justify-between items-center py-3 border-b border-[#C6A15B]/20">
                      <span className="font-medium text-[#171717]">Sitapura Industrial Area</span>
                      <span className="text-[#A9823F] font-bold text-base">1 km</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 10: BOOKING (#page-booking)          */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'booking' && (
          <section id="page-booking" className="w-full pt-20">
            <div className="h-[35vh] w-full flex flex-col justify-center items-center text-center px-6 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
              <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold">RESERVATIONS & ENQUIRIES</span>
              <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light mt-2">
                {bookingCategory === 'banquet' ? 'Book Banquet Hall' : 'Reserve Your Stay'}
              </h1>
            </div>

            <div className="max-w-3xl mx-auto px-6 py-16">
              
              {/* Category Switcher Tabs */}
              <div className="flex border border-[#C6A15B]/30 mb-8 bg-[#FAF7F2]">
                <button
                  type="button"
                  onClick={() => { setBookingCategory('room'); setBookingStep(1); setBookingConfirmed(false); }}
                  className={`flex-1 py-3.5 text-xs uppercase tracking-[0.2em] font-semibold transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                    bookingCategory === 'room' ? 'bg-[#C6A15B] text-white shadow-sm' : 'text-[#5C554B] hover:text-[#171717]'
                  }`}
                >
                  <Bed size={15} />
                  <span>Hotel Room Stay</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setBookingCategory('banquet'); setBookingStep(1); setBookingConfirmed(false); }}
                  className={`flex-1 py-3.5 text-xs uppercase tracking-[0.2em] font-semibold transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                    bookingCategory === 'banquet' ? 'bg-[#C6A15B] text-white shadow-sm' : 'text-[#5C554B] hover:text-[#171717]'
                  }`}
                >
                  <Building2 size={15} />
                  <span>Banquet Hall Event</span>
                </button>
              </div>

              <div className="bg-white border border-[#C6A15B]/25 p-8 sm:p-12 shadow-sm" data-reveal="scale-up">
                
                {bookingConfirmed ? (
                  <div className="text-center space-y-6 py-8">
                    <Check size={48} className="mx-auto text-[#C6A15B]" />
                    <h2 className="font-luxury text-4xl text-[#171717]">
                      {bookingCategory === 'banquet' ? 'Banquet Enquiry Received' : 'Reservation Received'}
                    </h2>
                    <p className="text-xs text-[#5C554B] leading-relaxed max-w-md mx-auto">
                      Thank you, <strong>{bookingData.name}</strong>. {bookingCategory === 'banquet' ? (
                        <>Your enquiry for <strong>{bookingData.eventType}</strong> on <strong>{bookingData.eventDate}</strong> ({bookingData.banquetGuests}) has been recorded.</>
                      ) : (
                        <>Your reservation for <strong>{bookingData.roomType}</strong> ({bookingData.checkIn} to {bookingData.checkOut}) has been submitted.</>
                      )}
                    </p>
                    <p className="text-[11px] text-[#A9823F] font-semibold">Reference ID: {serverBookingId || 'SKG-20260804-001'}</p>
                    <p className="text-xs uppercase tracking-widest text-amber-700 font-bold mt-1">Status: PENDING</p>
                    <p className="text-xs text-[#6B6256]">Our reservations team will call you shortly at <strong>{bookingData.phone}</strong> to confirm availability and details.</p>
                    <div className="pt-4 flex flex-wrap justify-center gap-4">
                      <button onClick={() => { setBookingConfirmed(false); setBookingStep(1); showPage('home'); }} className="explore-btn cursor-pointer">
                        RETURN TO HOME →
                      </button>
                      <a 
                        href={bookingCategory === 'banquet' ? (
                          `https://wa.me/919829063140?text=${encodeURIComponent(`Hello Hotel SK Grand, I would like to enquire about booking the Banquet Hall for a ${bookingData.eventType} on ${bookingData.eventDate} for ${bookingData.banquetGuests}. My name is ${bookingData.name} (${bookingData.phone}). ${bookingData.specialRequests ? 'Notes: ' + bookingData.specialRequests : ''}`)}`
                        ) : (
                          `https://wa.me/919829063140?text=${encodeURIComponent(`Hello Hotel SK Grand, I would like to enquire about booking a ${bookingData.roomType} from ${bookingData.checkIn} to ${bookingData.checkOut} for ${bookingData.guests}. My name is ${bookingData.name} (${bookingData.phone}). ${bookingData.specialRequests ? 'Notes: ' + bookingData.specialRequests : ''}`)}`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-emerald-700 hover:bg-emerald-800 text-white border border-emerald-500/40 text-xs px-6 py-3 uppercase tracking-widest font-semibold inline-flex items-center space-x-2 cursor-pointer transition-colors shadow-md"
                      >
                        <MessageCircle size={16} />
                        <span>SEND ON WHATSAPP (+91 98290 63140) →</span>
                      </a>
                    </div>
                  </div>
                ) : (
                  <div>
                    {/* Step indicator */}
                    <div className="flex justify-between items-center mb-8 border-b border-[#C6A15B]/20 pb-4 text-xs uppercase tracking-widest text-[#C6A15B] font-semibold">
                      {bookingCategory === 'room' ? (
                        <>
                          <span className={bookingStep >= 1 ? 'text-[#171717] font-bold' : ''}>1. Dates</span>
                          <span>→</span>
                          <span className={bookingStep >= 2 ? 'text-[#171717] font-bold' : ''}>2. Room</span>
                          <span>→</span>
                          <span className={bookingStep >= 3 ? 'text-[#171717] font-bold' : ''}>3. Guest Info</span>
                        </>
                      ) : (
                        <>
                          <span className={bookingStep >= 1 ? 'text-[#171717] font-bold' : ''}>1. Event Details</span>
                          <span>→</span>
                          <span className={bookingStep >= 2 ? 'text-[#171717] font-bold' : ''}>2. Contact & Requirements</span>
                        </>
                      )}
                    </div>

                    <form onSubmit={handleBookingSubmit} className="space-y-6">
                      {bookingError && (
                        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                          {bookingError}
                        </div>
                      )}
                      
                      {/* ROOM BOOKING FLOW */}
                      {bookingCategory === 'room' && (
                        <>
                          {bookingStep === 1 && (
                            <div className="space-y-6">
                              <h3 className="font-luxury text-2xl text-[#171717]">Step 1: Select Stay Dates</h3>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Check-in Date</label>
                                  <input 
                                    type="date" 
                                    required 
                                    value={bookingData.checkIn}
                                    onChange={(e) => setBookingData({ ...bookingData, checkIn: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  />
                                </div>
                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Check-out Date</label>
                                  <input 
                                    type="date" 
                                    required 
                                    value={bookingData.checkOut}
                                    onChange={(e) => setBookingData({ ...bookingData, checkOut: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  />
                                </div>
                              </div>

                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Number of Guests</label>
                                <select 
                                  value={bookingData.guests}
                                  onChange={(e) => setBookingData({ ...bookingData, guests: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                                >
                                  <option value="1 Guest">1 Guest</option>
                                  <option value="2 Guests">2 Guests</option>
                                  <option value="3 Guests">3 Guests</option>
                                  <option value="4+ Guests">4+ Guests</option>
                                </select>
                              </div>

                              <button type="submit" className="w-full explore-btn cursor-pointer">
                                NEXT: SELECT ROOM →
                              </button>
                            </div>
                          )}

                          {bookingStep === 2 && (
                            <div className="space-y-6">
                              <h3 className="font-luxury text-2xl text-[#171717]">Step 2: Select Room Type</h3>
                              
                              <div className="space-y-4">
                                {[
                                  { name: 'Deluxe Room', key: 'deluxe', desc: 'King bed, AC, Minibar, Soundproofed' },
                                  { name: 'Super Deluxe Room', key: 'super-deluxe', desc: 'Bathtub, City views, Hair dryer' },
                                  { name: 'Suite Room', key: 'suite', desc: 'Largest floor plan, VIP Jaipur vistas' },
                                  { name: 'Family Room', key: 'family', desc: 'Multi-bed layout, Family comfort & extra space' },
                                ].map((r) => (
                                  <label key={r.key} className={`block p-4 border cursor-pointer transition-colors ${bookingData.roomType === r.name ? 'border-[#C6A15B] bg-[#FAF7F2]' : 'border-[#C6A15B]/20 bg-transparent'}`}>
                                    <div className="flex items-center space-x-3">
                                      <input 
                                        type="radio" 
                                        name="roomSelection"
                                        checked={bookingData.roomType === r.name}
                                        onChange={() => setBookingData({ ...bookingData, roomType: r.name })}
                                      />
                                      <div>
                                        <strong className="text-sm text-[#171717] block">{r.name}</strong>
                                        <span className="text-xs text-[#5C554B]">{r.desc}</span>
                                      </div>
                                    </div>
                                  </label>
                                ))}
                              </div>

                              <div className="flex justify-between space-x-4">
                                <button type="button" onClick={() => setBookingStep(1)} className="border border-[#C6A15B]/40 text-xs px-6 py-3 cursor-pointer text-[#171717] font-semibold hover:bg-[#FAF7F2]">
                                  ← BACK
                                </button>
                                <button type="submit" className="explore-btn cursor-pointer">
                                  NEXT: GUEST DETAILS →
                                </button>
                              </div>
                            </div>
                          )}

                          {bookingStep === 3 && (
                            <div className="space-y-6">
                              <h3 className="font-luxury text-2xl text-[#171717]">Step 3: Contact Information</h3>
                              
                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Full Name</label>
                                <input 
                                  type="text" 
                                  required 
                                  value={bookingData.name}
                                  onChange={(e) => setBookingData({ ...bookingData, name: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  placeholder="John Doe"
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Phone Number</label>
                                  <input 
                                    type="tel" 
                                    required 
                                    value={bookingData.phone}
                                    onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                    placeholder="+91 XXXXX XXXXX"
                                  />
                                </div>

                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Email Address</label>
                                  <input 
                                    type="email" 
                                    required 
                                    value={bookingData.email}
                                    onChange={(e) => setBookingData({ ...bookingData, email: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                    placeholder="name@example.com"
                                  />
                                </div>
                              </div>

                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Special Requests (Optional)</label>
                                <textarea 
                                  rows={3}
                                  value={bookingData.specialRequests}
                                  onChange={(e) => setBookingData({ ...bookingData, specialRequests: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  placeholder="Airport pickup, early check-in notes..."
                                />
                              </div>

                              <div className="flex flex-col space-y-3">
                                <div className="flex justify-between space-x-4">
                                  <button type="button" onClick={() => setBookingStep(2)} className="border border-[#C6A15B]/40 text-xs px-6 py-3 cursor-pointer text-[#171717] font-semibold hover:bg-[#FAF7F2]">
                                    ← BACK
                                  </button>
                                </div>
                                <button 
                                  type="submit" 
                                  disabled={isSubmittingBooking}
                                  className="w-full bg-[#C6A15B] text-white py-3 text-xs uppercase tracking-widest font-semibold hover:bg-[#A9823F] transition-colors cursor-pointer shadow-sm disabled:opacity-50"
                                >
                                  {isSubmittingBooking ? 'Submitting Booking...' : 'SUBMIT RESERVATION →'}
                                </button>
                              </div>
                            </div>
                          )}
                        </>
                      )}

                      {/* BANQUET HALL BOOKING FLOW */}
                      {bookingCategory === 'banquet' && (
                        <>
                          {bookingStep === 1 && (
                            <div className="space-y-6">
                              <h3 className="font-luxury text-2xl text-[#171717]">Step 1: Event Details</h3>
                              
                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Event Type</label>
                                <select 
                                  value={bookingData.eventType}
                                  onChange={(e) => setBookingData({ ...bookingData, eventType: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                                >
                                  <option value="Wedding / Reception">Wedding / Reception</option>
                                  <option value="Engagement Ceremony">Engagement Ceremony</option>
                                  <option value="Birthday Party">Birthday Party</option>
                                  <option value="Anniversary Celebration">Anniversary Celebration</option>
                                  <option value="Corporate Meeting / Conference">Corporate Meeting / Conference</option>
                                  <option value="Family Gathering / Function">Family Gathering / Function</option>
                                  <option value="Other Event">Other Special Event</option>
                                </select>
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Target Event Date</label>
                                  <input 
                                    type="date" 
                                    required 
                                    value={bookingData.eventDate}
                                    onChange={(e) => setBookingData({ ...bookingData, eventDate: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  />
                                </div>

                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Expected Guest Count</label>
                                  <select 
                                    value={bookingData.banquetGuests}
                                    onChange={(e) => setBookingData({ ...bookingData, banquetGuests: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                                  >
                                    <option value="Up to 50 Guests">Up to 50 Guests</option>
                                    <option value="50 - 100 Guests">50 - 100 Guests</option>
                                    <option value="100 - 250 Guests">100 - 250 Guests</option>
                                    <option value="250 - 500 Guests">250 - 500 Guests</option>
                                    <option value="500+ Guests">500+ Guests</option>
                                  </select>
                                </div>
                              </div>

                              <button type="submit" className="w-full explore-btn cursor-pointer">
                                NEXT: CONTACT & REQUIREMENTS →
                              </button>
                            </div>
                          )}

                          {bookingStep === 2 && (
                            <div className="space-y-6">
                              <h3 className="font-luxury text-2xl text-[#171717]">Step 2: Contact & Event Requirements</h3>
                              
                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Full Name</label>
                                <input 
                                  type="text" 
                                  required 
                                  value={bookingData.name}
                                  onChange={(e) => setBookingData({ ...bookingData, name: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  placeholder="John Doe"
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Phone Number</label>
                                  <input 
                                    type="tel" 
                                    required 
                                    value={bookingData.phone}
                                    onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                    placeholder="+91 XXXXX XXXXX"
                                  />
                                </div>

                                <div>
                                  <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Email Address</label>
                                  <input 
                                    type="email" 
                                    required 
                                    value={bookingData.email}
                                    onChange={(e) => setBookingData({ ...bookingData, email: e.target.value })}
                                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                    placeholder="name@example.com"
                                  />
                                </div>
                              </div>

                              <div>
                                <label className="block text-xs uppercase tracking-wider text-[#A9823F] font-semibold mb-2">Event Requirements / Catering Notes (Optional)</label>
                                <textarea 
                                  rows={3}
                                  value={bookingData.specialRequests}
                                  onChange={(e) => setBookingData({ ...bookingData, specialRequests: e.target.value })}
                                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 p-3 text-sm text-[#171717] focus:outline-none focus:border-[#C6A15B]" 
                                  placeholder="Specify catering preference, stage arrangement, AV requirements..."
                                />
                              </div>

                              <div className="flex flex-col space-y-3">
                                <div className="flex justify-between space-x-4">
                                  <button type="button" onClick={() => setBookingStep(1)} className="border border-[#C6A15B]/40 text-xs px-6 py-3 cursor-pointer text-[#171717] font-semibold hover:bg-[#FAF7F2]">
                                    ← BACK
                                  </button>
                                </div>
                                <button 
                                  type="submit" 
                                  disabled={isSubmittingBooking}
                                  className="w-full bg-[#C6A15B] text-white py-3 text-xs uppercase tracking-widest font-semibold hover:bg-[#A9823F] transition-colors cursor-pointer shadow-sm disabled:opacity-50"
                                >
                                  {isSubmittingBooking ? 'Submitting Booking...' : 'SUBMIT BANQUET ENQUIRY →'}
                                </button>
                              </div>
                            </div>
                          )}
                        </>
                      )}

                    </form>
                  </div>
                )}

              </div>
            </div>

            <div className="back-home-section">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

        {/* ═══════════════════════════════════════════ */}
        {/* PAGE 11: REVIEWS PAGE (#page-reviews)      */}
        {/* ═══════════════════════════════════════════ */}
        {currentPage === 'reviews' && (
          <section id="page-reviews" className="w-full">
            <ReviewsPage
              onBackToHome={() => showPage('home')}
              onOpenBooking={() => openBooking('room')}
            />
            <div className="back-home-section pb-12 bg-[#FAF7F2]">
              <button onClick={() => showPage('home')} className="back-home-btn cursor-pointer">
                ← Back to Home
              </button>
            </div>
          </section>
        )}

      </main>

      {/* Global Write a Review Modal */}
      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => setIsReviewModalOpen(false)}
        onSuccess={refreshReviews}
      />

      {/* 9. FOOTER WITH SMOOTH MARQUEE */}
      <footer className="border-t border-[#C6A15B]/20 bg-[#FAF7F2] py-12 px-6 text-center text-xs tracking-widest text-[#5C554B] space-y-6">
        
        {/* Smooth Infinite Marquee */}
        <div className="marquee border-y border-[#C6A15B]/20 py-4 my-2 text-[#A9823F] font-semibold">
          <span>HOTEL SK GRAND · JAIPUR · EST. 2019 · TONK ROAD · HOTEL SK GRAND · JAIPUR · EST. 2019 · </span>
          <span>HOTEL SK GRAND · JAIPUR · EST. 2019 · TONK ROAD · HOTEL SK GRAND · JAIPUR · EST. 2019 · </span>
        </div>

        <div className="flex justify-center mb-3">
          <img 
            src="https://cdn.phototourl.com/member/2026-09-04-7a09cda6-9890-4a86-a1e5-5c33a2c48640.png" 
            alt="Hotel SK Grand Logo" 
            className="h-14 sm:h-16 w-auto object-contain" 
          />
        </div>
        <p className="text-[#171717] font-medium">Plot No. 1 & 2, Ram Nagar-A, Near Bambala Puliya, Tonk Road, Pratap Nagar, Jaipur — 302033</p>
        <div className="flex flex-wrap justify-center items-center gap-6 text-xs text-[#171717] pt-1 font-semibold">
          <a href="tel:+919829063140" className="flex items-center space-x-2 hover:text-[#C6A15B] transition-colors">
            <Phone size={14} className="text-[#C6A15B]" />
            <span>Call Primary: +91 98290 63140</span>
          </a>
          <a href="tel:+919828063140" className="flex items-center space-x-2 hover:text-[#C6A15B] transition-colors">
            <Phone size={14} className="text-[#C6A15B]" />
            <span>Call Secondary: +91 98280 63140</span>
          </a>
          <a 
            href="https://wa.me/919829063140?text=Hello%20Hotel%20SK%20Grand,%20I%20would%20like%20to%20enquire%20about%20a%20booking.%20Please%20share%20the%20availability%20and%20details." 
            target="_blank" 
            rel="noopener noreferrer" 
            className="flex items-center space-x-2 text-emerald-700 hover:text-emerald-800 transition-colors"
          >
            <MessageCircle size={14} />
            <span>WhatsApp: +91 98290 63140</span>
          </a>
        </div>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-3 text-[11px] text-[#6B6256]">
          <span>© {new Date().getFullYear()} HOTEL SK GRAND. ALL RIGHTS RESERVED.</span>
          <span className="hidden sm:inline text-[#C6A15B]/40">·</span>
          <span>
            Designed &amp; Developed by{' '}
            <a 
              href="https://venoy.online" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-[#A9823F] hover:text-[#C6A15B] font-medium transition-colors hover:underline"
            >
              Venoy
            </a>
          </span>
        </div>
      </footer>

      {/* Offline FAQ Chatbot */}
      <ChatbotWidget />

    </div>
  );
}
