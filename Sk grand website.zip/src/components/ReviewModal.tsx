import React, { useState } from 'react';
import { X, Star, CheckCircle2, ShieldCheck } from 'lucide-react';
import { reviewsService, Review } from '../lib/reviewsService';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [stayType, setStayType] = useState<'Business' | 'Couple' | 'Family' | 'Solo' | 'Other'>('Couple');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!title.trim()) {
      setErrorMessage('Please enter a review title.');
      return;
    }
    if (!message.trim()) {
      setErrorMessage('Please share your review message.');
      return;
    }

    setIsSubmitting(true);

    try {
      reviewsService.submitReview({
        name: name.trim(),
        email: email.trim(),
        rating,
        title: title.trim(),
        message: message.trim(),
        stayType
      });

      setIsSubmitting(false);
      setSubmitted(true);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      setErrorMessage('An unexpected error occurred while submitting. Please try again.');
    }
  };

  const resetAndClose = () => {
    setName('');
    setEmail('');
    setRating(5);
    setTitle('');
    setMessage('');
    setSubmitted(false);
    setErrorMessage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0D0D0D]/75 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-white border border-[#C6A15B]/40 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 bg-[#FAF7F2] border-b border-[#C6A15B]/20">
          <div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#C6A15B] font-semibold block">HOTEL SK GRAND</span>
            <h3 className="font-luxury text-2xl text-[#171717]">Guest Experience Review</h3>
          </div>
          <button 
            onClick={resetAndClose}
            className="p-2 text-[#5C554B] hover:text-[#171717] transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {submitted ? (
            <div className="text-center py-8 space-y-5 animate-fadeIn">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#FAF7F2] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B]">
                <CheckCircle2 size={36} />
              </div>
              <div className="space-y-2">
                <h4 className="font-luxury text-2xl text-[#171717]">Thank you for sharing your experience</h4>
                <p className="text-xs sm:text-sm text-[#5C554B] max-w-md mx-auto leading-relaxed">
                  Your review has been submitted and is awaiting verification. Once approved by our team, it will appear publicly.
                </p>
              </div>

              <div className="p-4 bg-[#FAF7F2] border border-[#C6A15B]/20 text-left space-y-2 max-w-md mx-auto rounded-none">
                <div className="flex items-center space-x-2 text-[#C6A15B] text-xs font-semibold">
                  <ShieldCheck size={16} />
                  <span className="uppercase tracking-wider">Moderation Status: Pending</span>
                </div>
                <p className="text-[11px] text-[#5C554B] leading-relaxed">
                  To ensure authentic guest feedback, all reviews undergo administrative review prior to public publication.
                </p>
              </div>

              <div className="pt-4">
                <button
                  onClick={resetAndClose}
                  className="bg-[#C6A15B] hover:bg-[#A9823F] text-white text-xs font-semibold px-8 py-3 uppercase tracking-widest transition-all cursor-pointer shadow-sm"
                >
                  CLOSE & RETURN
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs">
                  {errorMessage}
                </div>
              )}

              {/* Notice Banner */}
              <div className="flex items-start space-x-3 p-3.5 bg-[#FAF7F2] border border-[#C6A15B]/25">
                <ShieldCheck size={18} className="text-[#C6A15B] shrink-0 mt-0.5" />
                <p className="text-xs text-[#5C554B] leading-relaxed">
                  Your review will be published after verification. We strictly maintain authentic guest feedback and protect guest privacy.
                </p>
              </div>

              {/* Name & Email Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                    Full Name <span className="text-[#C6A15B]">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vikram Sharma"
                    required
                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                    Email Address <span className="text-[#C6A15B]">*</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. vikram@example.com"
                    required
                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                  />
                  <span className="text-[10px] text-[#5C554B] block">Private & never displayed publicly</span>
                </div>
              </div>

              {/* Rating & Stay Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div className="space-y-1.5">
                  <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                    Star Rating <span className="text-[#C6A15B]">*</span>
                  </label>
                  <div className="flex items-center space-x-1.5 pt-1">
                    {[1, 2, 3, 4, 5].map((star) => {
                      const isActive = (hoverRating !== null ? hoverRating : rating) >= star;
                      return (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(null)}
                          className="p-1 text-[#C6A15B] hover:scale-110 transition-transform cursor-pointer"
                          aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                        >
                          <Star
                            size={22}
                            fill={isActive ? '#C6A15B' : 'transparent'}
                            className={isActive ? 'text-[#C6A15B]' : 'text-gray-300'}
                          />
                        </button>
                      );
                    })}
                    <span className="text-xs font-semibold text-[#171717] ml-2">
                      {hoverRating !== null ? hoverRating : rating} / 5
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                    Travel Category
                  </label>
                  <select
                    value={stayType}
                    onChange={(e) => setStayType(e.target.value as any)}
                    className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                  >
                    <option value="Couple">Couple</option>
                    <option value="Family">Family</option>
                    <option value="Business">Business</option>
                    <option value="Solo">Solo</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Review Title */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                  Review Headline <span className="text-[#C6A15B]">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Excellent hospitalities & spacious Deluxe room"
                  required
                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B]"
                />
              </div>

              {/* Review Message */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium uppercase tracking-wider text-[#171717] block">
                  Detailed Experience <span className="text-[#C6A15B]">*</span>
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Share details about your stay, cleanliness, location, staff service, or dining..."
                  required
                  className="w-full bg-[#FAF7F2] border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B] resize-none"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={resetAndClose}
                  className="px-5 py-3 border border-[#C6A15B]/40 text-[#171717] hover:bg-gray-100 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-7 py-3 bg-[#C6A15B] hover:bg-[#A9823F] text-white text-xs font-semibold uppercase tracking-widest transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'SUBMITTING...' : 'SUBMIT REVIEW'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
