import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Trash2, User } from 'lucide-react';
import { ChatMessage, getBotResponse, QUICK_QUESTIONS } from '../lib/chatbotService';

// Refined Hotel SK Grand Concierge Monogram Icon
const SKMonogramIcon: React.FC<{ className?: string }> = ({ className = '' }) => (
  <span className={`font-serif tracking-tighter text-[#C6A15B] font-bold text-[13px] leading-none select-none ${className}`}>
    SK
  </span>
);

export const ChatbotWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'bot',
      text: 'Namaste! Welcome to Hotel SK Grand, Tonk Road, Jaipur. I am your offline assistant. How can I help you with our rooms, location, dining, or banquet facilities today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [isOpen, messages, isTyping]);

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsTyping(true);

    // Simulate natural offline response delay (400ms - 800ms)
    const delay = Math.floor(Math.random() * 400) + 400;
    setTimeout(() => {
      const botReplyText = getBotResponse(userMsg.text);
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: botReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, delay);
  };

  const handleQuickQuestion = (qq: string) => {
    let query = qq;
    if (qq === 'Rooms & Facilities') query = 'What rooms and amenities are available?';
    if (qq === 'Location & Airport') query = 'Where is the hotel located and how far is the airport?';
    if (qq === 'Restaurant & Dining') query = 'Tell me about the restaurant and food service.';
    if (qq === 'Banquet & Weddings') query = 'Do you have a banquet hall for weddings and events?';
    if (qq === 'Check-in & Parking') query = 'What are the check-in timings and is parking free?';
    if (qq === 'How to Book') query = 'How can I book a room?';

    handleSendMessage(query);
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'msg-welcome',
        sender: 'bot',
        text: 'Chat cleared. How else may I assist you with Hotel SK Grand, Jaipur?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="group relative flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 bg-[#FAF7F2] hover:bg-white text-[#171717] border border-[#C6A15B]/60 hover:border-[#C6A15B] rounded-full shadow-lg hover:shadow-[0_0_15px_rgba(198,161,91,0.3)] transition-all duration-300 hover:scale-105 cursor-pointer"
          aria-label="Open SK Grand Concierge Assistant"
        >
          <SKMonogramIcon className="text-[13px] sm:text-[14px]" />
          <span className="absolute top-0 right-0 w-2 h-2 bg-[#C6A15B] rounded-full border border-white" />
        </button>
      )}

      {/* Chat Window Popup */}
      {isOpen && (
        <div className="w-[92vw] sm:w-[400px] h-[550px] bg-white border border-[#C6A15B]/40 shadow-2xl rounded-xl flex flex-col overflow-hidden animate-fadeIn">
          {/* Header */}
          <div className="bg-[#FAF7F2] border-b border-[#C6A15B]/20 px-5 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-full bg-[#0D0D0D] border border-[#C6A15B]/50 text-white flex items-center justify-center shadow-xs">
                <SKMonogramIcon className="text-[13px]" />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <h3 className="font-luxury text-base text-[#171717] font-semibold">SK Grand Assistant</h3>
                  <span className="text-[9px] uppercase tracking-widest bg-[#C6A15B]/10 text-[#C6A15B] font-semibold px-1.5 py-0.5 rounded-xs">Offline FAQ</span>
                </div>
                <p className="text-[11px] text-[#5C554B]">Tonk Road, Jaipur · Instant Support</p>
              </div>
            </div>

            <div className="flex items-center space-x-1 text-[#5C554B]">
              <button
                onClick={handleClearChat}
                title="Clear conversation"
                className="p-1.5 hover:text-[#171717] hover:bg-black/5 rounded transition-colors cursor-pointer"
              >
                <Trash2 size={16} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close chat"
                className="p-1.5 hover:text-[#171717] hover:bg-black/5 rounded transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Quick Question Pills */}
          <div className="bg-[#FAF7F2]/60 border-b border-[#C6A15B]/15 px-3 py-2.5 overflow-x-auto flex space-x-2 shrink-0 scrollbar-none">
            {QUICK_QUESTIONS.map((qq, idx) => (
              <button
                key={idx}
                onClick={() => handleQuickQuestion(qq)}
                className="whitespace-nowrap bg-white border border-[#C6A15B]/30 hover:border-[#C6A15B] text-[#171717] text-[11px] px-3 py-1 rounded-full transition-all cursor-pointer shadow-2xs font-medium"
              >
                {qq}
              </button>
            ))}
          </div>

          {/* Messages Container */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-white">
            {messages.map((msg) => {
              const isBot = msg.sender === 'bot';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start space-x-2.5 ${isBot ? '' : 'flex-row-reverse space-x-reverse'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                      isBot ? 'bg-[#0D0D0D] border border-[#C6A15B]/40 text-white' : 'bg-[#171717] text-white'
                    }`}
                  >
                    {isBot ? <SKMonogramIcon className="text-[11px]" /> : <User size={14} />}
                  </div>

                  <div
                    className={`max-w-[78%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-2xs ${
                      isBot
                        ? 'bg-[#FAF7F2] border border-[#C6A15B]/25 text-[#171717] rounded-tl-xs'
                        : 'bg-[#171717] text-[#FAF7F2] rounded-tr-xs'
                    }`}
                  >
                    <p className="whitespace-pre-line">{msg.text}</p>
                    <span
                      className={`block text-[9px] mt-1.5 text-right font-mono ${
                        isBot ? 'text-gray-400' : 'text-gray-300'
                      }`}
                    >
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex items-start space-x-2.5 animate-fadeIn">
                <div className="w-7 h-7 rounded-full bg-[#0D0D0D] border border-[#C6A15B]/40 text-white flex items-center justify-center shrink-0">
                  <SKMonogramIcon className="text-[11px]" />
                </div>
                <div className="bg-[#FAF7F2] border border-[#C6A15B]/25 px-4 py-3 rounded-2xl rounded-tl-xs flex items-center space-x-1.5">
                  <span className="w-1.5 h-1.5 bg-[#C6A15B] rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 bg-[#C6A15B] rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 bg-[#C6A15B] rounded-full animate-bounce" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Footer Input Area */}
          <div className="p-3 bg-[#FAF7F2] border-t border-[#C6A15B]/20">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center space-x-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ask about rooms, location, banquet, check-in..."
                className="flex-1 bg-white border border-[#C6A15B]/30 px-3.5 py-2.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B] rounded-md"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="bg-[#C6A15B] hover:bg-[#A9823F] disabled:opacity-40 text-white p-2.5 rounded-md transition-colors cursor-pointer shrink-0"
                aria-label="Send message"
              >
                <Send size={16} />
              </button>
            </form>
            <div className="text-center pt-2">
              <span className="text-[9px] text-[#5C554B] tracking-wider uppercase">
                Offline FAQ Assistant · Powered by Hotel SK Grand Knowledge Base
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

