import React, { useState, useEffect } from 'react';

interface CinematicLoaderProps {
  onComplete: () => void;
}

export const CinematicLoader: React.FC<CinematicLoaderProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    // Check for prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Simulate or track asset preloading with smooth progress animation
    let currentProgress = 0;
    const intervalTime = prefersReducedMotion ? 40 : 25;
    
    const timer = setInterval(() => {
      currentProgress += Math.floor(Math.random() * 8) + 3;
      if (currentProgress >= 100) {
        currentProgress = 100;
        clearInterval(timer);
        setProgress(100);

        // Start fade out transition
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            setIsComplete(true);
            onComplete();
          }, 800); // 800ms fade transition
        }, 300);
      } else {
        setProgress(currentProgress);
      }
    }, intervalTime);

    // Sensible maximum fallback timeout so user is never stuck
    const fallbackTimer = setTimeout(() => {
      if (!isComplete) {
        clearInterval(timer);
        setProgress(100);
        setIsFadingOut(true);
        setTimeout(() => {
          setIsComplete(true);
          onComplete();
        }, 800);
      }
    }, 2800);

    return () => {
      clearInterval(timer);
      clearTimeout(fallbackTimer);
    };
  }, [onComplete]);

  if (isComplete) return null;

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#FAF7F2] text-[#171717] transition-opacity duration-800 ease-out select-none ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ width: '100vw', height: '100vh' }}
    >
      <div className="relative z-10 flex flex-col items-center max-w-sm px-6 text-center space-y-8 animate-fadeIn">
        {/* Existing SK Grand Logo */}
        <div className="space-y-4">
          <img 
            src="https://cdn.phototourl.com/member/2026-09-04-7a09cda6-9890-4a86-a1e5-5c33a2c48640.png" 
            alt="Hotel SK Grand Logo" 
            className="h-16 sm:h-20 w-auto object-contain mx-auto filter drop-shadow-sm transition-transform duration-1000 scale-100 opacity-95"
          />
          <div className="space-y-1">
            <span className="text-[10px] uppercase tracking-[0.35em] text-[#C6A15B] font-semibold block">
              HOTEL SK GRAND
            </span>
            <span className="text-[9px] uppercase tracking-[0.25em] text-[#5C554B] font-light block">
              TONK ROAD · JAIPUR
            </span>
          </div>
        </div>

        {/* Minimal Progress Bar & Status */}
        <div className="w-48 sm:w-56 space-y-3">
          <div className="w-full bg-[#E5DFD3] h-[2px] rounded-none overflow-hidden relative">
            <div 
              className="absolute top-0 left-0 bottom-0 bg-[#C6A15B] transition-all duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[9px] tracking-[0.3em] text-[#5C554B] font-mono uppercase">
            <span>LOADING</span>
            <span>{progress}%</span>
          </div>
        </div>
      </div>

      {/* Subtle Ambient Luxury Background Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(198,161,91,0.06)_0%,transparent_70%)] pointer-events-none" />
    </div>
  );
};
