import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Check, ArrowRight } from 'lucide-react';

interface Room {
  id: string;
  title: string;
  image: string;
  description: string;
  amenities: string[];
  capacity: string;
  bedType: string;
  gallery: string[];
}

interface RoomsPageProps {
  onReturnHome: () => void;
  setActiveToast: (toast: string | null) => void;
}

export default function RoomsPage({ onReturnHome, setActiveToast }: RoomsPageProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    const revealElements = document.querySelectorAll('[data-reveal]');
    revealElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const rooms: Room[] = [
    {
      id: '01',
      title: 'DELUXE ROOM',
      image: 'https://cdn.corenexis.com/f/v4fRnCMJylm.jpg',
      description: 'Comfortable king-sized room featuring air conditioning, LED TV with satellite channels, minibar, tea & coffee maker, soundproofed windows, writing desk, in-room safe, and electronic keyguard.',
      amenities: ['King-Sized Bed', 'Air Conditioning', 'LED TV with Satellite', 'Minibar / Fridge', 'Tea & Coffee Maker', 'Soundproofed Windows', 'Writing Desk', 'In-Room Safe'],
      capacity: '2 Guests',
      bedType: 'King Size Bed',
      gallery: ['https://cdn.corenexis.com/f/v4fRnCMJylm.jpg']
    },
    {
      id: '02',
      title: 'SUPER DELUXE ROOM',
      image: 'https://cdn.corenexis.com/f/5IEiRUBt6eJ.jpg',
      description: 'Elevated comfort offering all Deluxe amenities plus bathtub (select rooms), stunning city and Jaipur views from higher floors, in-room dining area, hair dryer, and separate shower facilities.',
      amenities: ['All Deluxe Amenities', 'Bathtub (Select Rooms)', 'City & Jaipur Views', 'In-Room Dining Area', 'Hair Dryer', 'Bidet & Shower'],
      capacity: '2 Guests',
      bedType: 'Queen / King Bed',
      gallery: ['https://cdn.corenexis.com/f/5IEiRUBt6eJ.jpg']
    },
    {
      id: '03',
      title: 'SUITE ROOM',
      image: 'https://cdn.corenexis.com/f/Kwd1D7uPXNI.jpg',
      description: 'Our most expansive and luxurious living quarters, offering larger living space, premium furnishings, and the absolute best floor views of Jaipur.',
      amenities: ['All Super Deluxe Amenities', 'Expansive Living Space', 'Premium Designer Furnishings', 'Best Panoramic Floor Views', 'Dedicated Service'],
      capacity: '3 Guests',
      bedType: 'Master King Bed',
      gallery: [
        'https://cdn.corenexis.com/f/Kwd1D7uPXNI.jpg'
      ]
    },
    {
      id: '04',
      title: 'FAMILY ROOM',
      image: 'https://cdn.phototourl.com/free/2026-09-04-da0d539e-5e95-4b01-bd9e-2a90de0d48b6.jpg',
      description: 'Generous room dimensions tailored for family stays, offering multi-bed layouts, spacious living nook, and premium amenities in Jaipur.',
      amenities: ['Multiple Bed Layouts', 'Generous Spatial Layout', 'In-Room Dining Nook', 'Family Amenities', '24/7 Hot Geyser'],
      capacity: '4 Guests',
      bedType: 'Double / Family Beds',
      gallery: [
        'https://cdn.phototourl.com/free/2026-09-04-da0d539e-5e95-4b01-bd9e-2a90de0d48b6.jpg'
      ]
    },
  ];

  return (
    <div className="relative min-h-screen bg-[#0D0D0D] text-[#F5F0E8] font-sans selection:bg-[#B8875A]/30 selection:text-white overflow-x-hidden">
      
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#0D0D0D]/95 backdrop-blur-xl border-b border-[#2A2520] flex justify-between items-center px-8 sm:px-16 py-8">
        <button 
          onClick={onReturnHome}
          className="font-luxury text-2xl sm:text-3xl tracking-[0.3em] font-light text-[#F5F0E8] hover:text-[#E8D5A3] transition-colors cursor-pointer"
        >
          SK GRAND
        </button>
        <nav className="hidden md:flex items-center space-x-12 text-[11px] uppercase tracking-[0.3em] font-medium text-[#F5F0E8]/80">
          <button onClick={onReturnHome} className="hover:text-white transition-colors cursor-pointer">HOME</button>
          <button className="text-[#B8875A] transition-colors cursor-pointer">STAY</button>
          <button onClick={() => { setActiveToast('Dining section selected — Hotel SK Grand'); setTimeout(() => setActiveToast(null), 3000); }} className="hover:text-white transition-colors cursor-pointer">DINING</button>
          <button onClick={() => { setActiveToast('Experience section selected — Hotel SK Grand'); setTimeout(() => setActiveToast(null), 3000); }} className="hover:text-white transition-colors cursor-pointer">EXPERIENCE</button>
          <button onClick={() => { setActiveToast('Contact section selected — Hotel SK Grand'); setTimeout(() => setActiveToast(null), 3000); }} className="hover:text-white transition-colors cursor-pointer">CONTACT</button>
        </nav>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden text-[#F5F0E8] p-2 focus:outline-none"
        >
          {mobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
        </button>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-[#0D0D0D]/98 backdrop-blur-2xl p-10 flex flex-col space-y-8 pt-32">
          <button onClick={() => setMobileMenuOpen(false)} className="absolute top-8 right-8 text-[#F5F0E8]"><X size={28} /></button>
          <button onClick={() => { onReturnHome(); setMobileMenuOpen(false); }} className="font-luxury text-4xl text-left tracking-[0.15em] text-[#F5F0E8]">HOME</button>
          <button onClick={() => setMobileMenuOpen(false)} className="font-luxury text-4xl text-left tracking-[0.15em] text-[#B8875A]">STAY</button>
          <button onClick={() => { setActiveToast('Dining selected'); setMobileMenuOpen(false); }} className="font-luxury text-4xl text-left tracking-[0.15em] text-[#F5F0E8]">DINING</button>
          <button onClick={() => { setActiveToast('Experience selected'); setMobileMenuOpen(false); }} className="font-luxury text-4xl text-left tracking-[0.15em] text-[#F5F0E8]">EXPERIENCE</button>
        </div>
      )}

      {/* 1. Rooms Page Hero */}
      <section className="relative h-[65vh] flex items-center justify-center overflow-hidden px-8 text-center bg-[#0D0D0D]">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&q=80&w=1600" 
            alt="Hotel SK Grand Rooms"
            className="w-full h-full object-cover object-center filter brightness-[0.75] contrast-[1.05]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/40 to-[#0D0D0D]/60" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto space-y-6">
          <span className="text-[11px] uppercase tracking-[0.35em] font-medium text-[#B8875A]">
            STAY AT SK GRAND
          </span>
          <h1 className="font-luxury font-light text-5xl sm:text-7xl tracking-[-0.02em] text-[#F5F0E8]">
            Rooms Designed for a Comfortable Stay
          </h1>
          <p className="text-base sm:text-lg text-[#F5F0E8]/75 font-light max-w-2xl mx-auto leading-relaxed">
            Discover thoughtfully designed spaces created for relaxing, comfortable and memorable stays.
          </p>
        </div>
      </section>

      {/* 2. Signature Room Intro ("THE STAY") */}
      <section data-reveal="slide-left" className="py-32 sm:py-44 px-8 sm:px-16 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24 items-center border-b border-[#2A2520]">
        <div className="lg:col-span-6 relative group">
          <div className="relative overflow-hidden aspect-[4/5] bg-[#1A1A1A] shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&q=80&w=1400"
              alt="A Space to Slow Down"
              className="w-full h-full object-cover object-center"
            />
            <div className="grain-overlay" />
          </div>
        </div>

        <div className="lg:col-span-6 space-y-8">
          <span className="text-[11px] uppercase tracking-[0.3em] font-medium text-[#B8875A]">
            THE STAY
          </span>
          <h2 className="font-luxury font-light text-4xl sm:text-6xl tracking-[-0.02em] text-[#F5F0E8]">
            A Space to Slow Down
          </h2>
          <p className="text-base sm:text-lg text-[#F5F0E8]/75 font-light leading-[1.8]">
            Every room at Hotel SK Grand is a curated sanctuary of calm. Featuring refined furnishings, plush bedding, and soothing aesthetic details, our accommodations offer an atmosphere of absolute tranquility.
          </p>
          <div className="flex items-center space-x-4 pt-4">
            <div className="w-12 h-[1px] bg-[#B8875A]" />
            <span className="text-xs font-mono tracking-[0.3em] text-[#B8875A]">SK GRAND COLLECTION</span>
          </div>
        </div>
      </section>

      {/* 3. Room Collection & Alternating Presentation */}
      <section className="py-32 sm:py-44 px-8 sm:px-16 max-w-7xl mx-auto space-y-36">
        <div data-reveal="slide-right" className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-[11px] uppercase tracking-[0.3em] font-medium text-[#B8875A]">
            ACCOMMODATION PORTFOLIO
          </span>
          <h2 className="font-luxury font-light text-4xl sm:text-6xl tracking-[-0.02em] text-[#F5F0E8]">
            Explore Our Rooms
          </h2>
          <p className="text-base text-[#F5F0E8]/70 font-light">
            Select your preferred sanctuary for your upcoming stay.
          </p>
        </div>

        {rooms.map((room, idx) => {
          const isEven = idx % 2 === 0;
          return (
            <div
              key={room.id}
              data-reveal="scale-up"
              style={{ transitionDelay: `${idx * 0.2}s` }}
              className={`grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24 items-center ${
                isEven ? '' : 'lg:flex-row-reverse'
              }`}
            >
              {/* Image Block */}
              <div className={`lg:col-span-7 ${isEven ? 'order-1' : 'order-1 lg:order-2'}`}>
                <div className="relative overflow-hidden aspect-[16/10] bg-[#1A1A1A] shadow-2xl group border border-[#2A2520]">
                  <img
                    src={room.image}
                    alt={room.title}
                    className="w-full h-full object-cover object-center"
                  />
                  <div className="grain-overlay" />
                  <div className="absolute top-4 left-4 bg-[#0D0D0D]/80 backdrop-blur-md px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-[#E8D5A3] border border-[#2A2520]">
                    {room.capacity} • {room.bedType}
                  </div>
                </div>
              </div>

              {/* Content Block */}
              <div className={`lg:col-span-5 space-y-6 ${isEven ? 'order-2' : 'order-2 lg:order-1'}`}>
                <div className="space-y-2">
                  <span className="text-xs font-mono text-[#B8875A] tracking-[0.3em]">
                    ROOM {room.id}
                  </span>
                  <h3 className="font-luxury font-light text-3xl sm:text-4xl tracking-[0.05em] text-[#F5F0E8]">
                    {room.title}
                  </h3>
                </div>

                <p className="text-base text-[#F5F0E8]/75 font-light leading-relaxed">
                  {room.description}
                </p>

                {/* Amenities */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  {room.amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center space-x-2 text-xs text-[#F5F0E8]/80">
                      <Check size={14} className="text-[#B8875A]" />
                      <span>{amenity}</span>
                    </div>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center space-x-6 pt-6">
                  <button
                    onClick={() => setSelectedRoom(room)}
                    className="px-6 py-3 text-xs uppercase tracking-[0.25em] font-medium border border-[#E8D5A3] text-[#E8D5A3] hover:bg-[#B8875A] hover:text-[#0D0D0D] transition-colors cursor-pointer"
                  >
                    VIEW ROOM
                  </button>
                  <button
                    onClick={() => {
                      setActiveToast(`Reservation inquiry for ${room.title} — Hotel SK Grand`);
                      setTimeout(() => setActiveToast(null), 3000);
                    }}
                    className="px-6 py-3 text-xs uppercase tracking-[0.25em] font-medium bg-[#B8875A] text-[#0D0D0D] hover:bg-[#E8D5A3] transition-colors cursor-pointer"
                  >
                    BOOK NOW
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* 11. Booking CTA */}
      <section className="relative py-36 px-8 sm:px-16 text-center bg-[#0D0D0D] overflow-hidden border-t border-[#2A2520]">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&q=80&w=1600"
            alt="Your Stay Awaits"
            className="w-full h-full object-cover object-center filter brightness-[0.5]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/70 to-[#0D0D0D]/90" />
        </div>

        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          <span className="text-[11px] uppercase tracking-[0.35em] font-medium text-[#B8875A]">
            YOUR STAY AWAITS
          </span>
          <h2 className="font-luxury font-light text-4xl sm:text-6xl tracking-[-0.02em] text-[#F5F0E8]">
            Find Your Space at Hotel SK Grand
          </h2>
          <p className="text-base sm:text-lg text-[#F5F0E8]/80 font-light max-w-xl mx-auto leading-relaxed">
            Experience refined comfort and warm hospitality tailored to your journey.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 pt-6">
            <button
              onClick={() => {
                setActiveToast('Redirecting to secure room reservation — Hotel SK Grand');
                setTimeout(() => setActiveToast(null), 3000);
              }}
              className="w-full sm:w-auto px-8 py-4 bg-[#B8875A] text-[#0D0D0D] text-xs uppercase tracking-[0.3em] font-medium hover:bg-[#E8D5A3] transition-colors cursor-pointer shadow-xl"
            >
              BOOK YOUR STAY
            </button>
            <button
              onClick={onReturnHome}
              className="w-full sm:w-auto px-8 py-4 border border-[#E8D5A3] text-[#E8D5A3] text-xs uppercase tracking-[0.3em] font-medium hover:bg-[#B8875A] hover:text-[#0D0D0D] transition-colors cursor-pointer"
            >
              RETURN TO HOME
            </button>
          </div>
        </div>
      </section>

      {/* Room Detail Modal / Drawer */}
      <AnimatePresence>
        {selectedRoom && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-[#1A1A1A] border border-[#2A2520] shadow-2xl text-[#F5F0E8] max-h-[90vh] flex flex-col"
            >
              <button
                onClick={() => setSelectedRoom(null)}
                className="absolute top-6 right-6 z-20 w-10 h-10 bg-[#0D0D0D] text-[#F5F0E8] flex items-center justify-center hover:bg-[#B8875A] hover:text-[#0D0D0D] transition-colors cursor-pointer"
              >
                <X size={20} />
              </button>

              <div className="relative aspect-[16/9] bg-black overflow-hidden flex-shrink-0">
                <img
                  src={selectedRoom.image}
                  alt={selectedRoom.title}
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A] via-transparent to-transparent" />
                <div className="absolute bottom-6 left-8">
                  <span className="text-xs uppercase tracking-[0.3em] text-[#B8875A]">{selectedRoom.capacity} • {selectedRoom.bedType}</span>
                  <h3 className="font-luxury font-light text-3xl sm:text-4xl text-white mt-1">{selectedRoom.title}</h3>
                </div>
              </div>

              <div className="p-8 sm:p-12 space-y-8 overflow-y-auto">
                <div className="space-y-3">
                  <h4 className="text-xs uppercase tracking-[0.3em] text-[#B8875A]">Room Overview</h4>
                  <p className="text-base sm:text-lg text-[#F5F0E8]/80 font-light leading-relaxed">
                    {selectedRoom.description}
                  </p>
                </div>

                <div className="space-y-4">
                  <h4 className="text-xs uppercase tracking-[0.3em] text-[#B8875A]">Included Amenities</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {selectedRoom.amenities.map((amenity) => (
                      <div key={amenity} className="flex items-center space-x-2 text-xs bg-[#0D0D0D] border border-[#2A2520] p-4">
                        <Check size={14} className="text-[#B8875A]" />
                        <span>{amenity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedRoom.gallery && selectedRoom.gallery.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-xs uppercase tracking-[0.3em] text-[#B8875A]">Room Gallery ({selectedRoom.gallery.length} Views)</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {selectedRoom.gallery.map((gImg, gIdx) => (
                        <div key={gIdx} className="aspect-[4/3] bg-[#0D0D0D] border border-[#2A2520] overflow-hidden group">
                          <img src={gImg} alt={`${selectedRoom.title} photo ${gIdx + 1}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-end space-x-6 pt-6 border-t border-[#2A2520]">
                  <button
                    onClick={() => setSelectedRoom(null)}
                    className="px-6 py-3 text-xs uppercase tracking-[0.25em] font-medium border border-[#E8D5A3] text-[#E8D5A3] hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    CLOSE
                  </button>
                  <button
                    onClick={() => {
                      setActiveToast(`Reservation confirmed for ${selectedRoom.title} — Hotel SK Grand`);
                      setSelectedRoom(null);
                      setTimeout(() => setActiveToast(null), 3000);
                    }}
                    className="px-8 py-3 text-xs uppercase tracking-[0.25em] font-medium bg-[#B8875A] text-[#0D0D0D] hover:bg-[#E8D5A3] transition-colors cursor-pointer shadow-lg"
                  >
                    BOOK THIS ROOM
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
