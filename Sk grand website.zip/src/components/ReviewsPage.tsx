import React, { useState, useEffect } from 'react';
import { Star, ShieldCheck, CheckCircle2, MessageSquare, Filter, Plus, Calendar, Award, User } from 'lucide-react';
import { reviewsService, Review } from '../lib/reviewsService';
import { ReviewModal } from './ReviewModal';

interface ReviewsPageProps {
  onBackToHome?: () => void;
  onOpenBooking?: () => void;
}

export const ReviewsPage: React.FC<ReviewsPageProps> = ({ onBackToHome, onOpenBooking }) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [summary, setSummary] = useState(reviewsService.getRatingSummary());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filterRating, setFilterRating] = useState<number | 'all'>('all');
  const [filterStay, setFilterStay] = useState<string>('all');

  const refreshReviews = () => {
    setReviews(reviewsService.getApprovedReviews());
    setSummary(reviewsService.getRatingSummary());
  };

  useEffect(() => {
    refreshReviews();
  }, []);

  const filteredReviews = reviews.filter((r) => {
    if (filterRating !== 'all' && Math.round(r.rating) !== filterRating) return false;
    if (filterStay !== 'all' && r.stayType !== filterStay) return false;
    return true;
  });

  return (
    <div className="w-full pt-20 pb-24 bg-[#FAF7F2] min-h-screen animate-fadeIn">
      {/* Hero Header */}
      <div className="relative py-16 px-6 sm:px-12 bg-white border-b border-[#C6A15B]/20 text-center space-y-4">
        <div className="max-w-4xl mx-auto space-y-3" data-reveal="fade-up">
          <span className="text-xs uppercase tracking-[0.3em] text-[#C6A15B] font-semibold block">HOTEL SK GRAND · JAIPUR</span>
          <h1 className="font-luxury text-4xl sm:text-6xl text-[#171717] font-light">Guest Reviews & Testimonials</h1>
          <p className="text-xs sm:text-sm text-[#5C554B] max-w-xl mx-auto leading-relaxed font-light">
            Read verified experiences from our valued corporate travelers, couples, and family guests at Tonk Road, Jaipur.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 sm:px-12 py-12 space-y-12">
        {/* Rating Summary Card */}
        <div className="bg-white border border-[#C6A15B]/30 p-8 sm:p-10 shadow-sm" data-reveal="scale-up">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Big Score Box */}
            <div className="lg:col-span-4 text-center lg:text-left space-y-3 lg:border-r border-[#C6A15B]/20 lg:pr-8">
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#C6A15B] font-semibold block">OVERALL RATING</span>
              <div className="flex items-baseline justify-center lg:justify-start space-x-2">
                <span className="font-luxury text-5xl sm:text-6xl text-[#171717] font-light">{summary.averageRating}</span>
                <span className="text-lg text-[#5C554B]">/ 5</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start space-x-1 text-[#C6A15B]">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    size={20}
                    fill={star <= Math.round(summary.averageRating) ? '#C6A15B' : 'transparent'}
                    className={star <= Math.round(summary.averageRating) ? 'text-[#C6A15B]' : 'text-gray-300'}
                  />
                ))}
              </div>
              <p className="text-xs text-[#5C554B] font-medium pt-1">
                Based on <span className="text-[#171717] font-bold">{summary.totalReviews} verified public reviews</span>
              </p>
            </div>

            {/* Star Distribution Bars */}
            <div className="lg:col-span-5 space-y-2.5">
              {[5, 4, 3, 2, 1].map((stars) => {
                const count = summary.starDistribution[stars] || 0;
                const percentage = summary.totalReviews > 0 ? Math.round((count / summary.totalReviews) * 100) : 0;
                return (
                  <div key={stars} className="flex items-center space-x-3 text-xs text-[#5C554B]">
                    <span className="w-12 text-right font-medium shrink-0">{stars} Stars</span>
                    <div className="flex-1 bg-[#FAF7F2] h-2.5 border border-[#C6A15B]/20 overflow-hidden">
                      <div
                        className="bg-[#C6A15B] h-full transition-all duration-500"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="w-10 text-right text-[11px] font-mono shrink-0">{count}</span>
                  </div>
                );
              })}
            </div>

            {/* Write Review Action Box */}
            <div className="lg:col-span-3 flex flex-col justify-center items-center lg:items-end text-center lg:text-right space-y-4 lg:pl-6">
              <div className="space-y-1">
                <span className="text-xs uppercase tracking-widest text-[#C6A15B] font-semibold block">Stayed with us?</span>
                <p className="text-xs text-[#5C554B]">We value your authentic feedback.</p>
              </div>
              <button
                onClick={() => setIsModalOpen(true)}
                className="bg-[#C6A15B] hover:bg-[#A9823F] text-white text-xs font-semibold py-3.5 px-6 uppercase tracking-widest transition-all shadow-sm flex items-center space-x-2 cursor-pointer"
              >
                <Plus size={16} />
                <span>WRITE A REVIEW</span>
              </button>
            </div>
          </div>
        </div>

        {/* Filters & Header Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-4 border-t border-[#C6A15B]/20">
          <div className="flex items-center space-x-2 text-xs text-[#171717]">
            <Filter size={14} className="text-[#C6A15B]" />
            <span className="font-semibold uppercase tracking-wider">Filter Reviews:</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Rating Filter */}
            <div className="flex items-center space-x-1 bg-white border border-[#C6A15B]/30 p-1 text-xs">
              <button
                onClick={() => setFilterRating('all')}
                className={`px-3 py-1 font-medium cursor-pointer transition-colors ${filterRating === 'all' ? 'bg-[#C6A15B] text-white' : 'text-[#5C554B] hover:text-[#171717]'}`}
              >
                All Ratings
              </button>
              {[5, 4, 3].map((r) => (
                <button
                  key={r}
                  onClick={() => setFilterRating(r)}
                  className={`px-2.5 py-1 font-medium cursor-pointer transition-colors ${filterRating === r ? 'bg-[#C6A15B] text-white' : 'text-[#5C554B] hover:text-[#171717]'}`}
                >
                  {r} ★
                </button>
              ))}
            </div>

            {/* Travel Category Filter */}
            <select
              value={filterStay}
              onChange={(e) => setFilterStay(e.target.value)}
              className="bg-white border border-[#C6A15B]/30 px-3 py-1.5 text-xs text-[#171717] focus:outline-none focus:border-[#C6A15B]"
            >
              <option value="all">All Categories</option>
              <option value="Couple">Couple</option>
              <option value="Family">Family</option>
              <option value="Business">Business</option>
              <option value="Solo">Solo</option>
            </select>
          </div>
        </div>

        {/* Reviews Cards List */}
        {filteredReviews.length === 0 ? (
          <div className="bg-white border border-[#C6A15B]/20 p-12 text-center space-y-4">
            <MessageSquare size={32} className="mx-auto text-[#C6A15B]/50" />
            <p className="text-sm text-[#5C554B]">No approved reviews match the selected filter criteria.</p>
            <button
              onClick={() => { setFilterRating('all'); setFilterStay('all'); }}
              className="text-xs text-[#C6A15B] font-semibold underline cursor-pointer"
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredReviews.map((rev) => (
              <div
                key={rev.id}
                className="bg-white border border-[#C6A15B]/25 p-7 flex flex-col justify-between space-y-4 shadow-sm hover:border-[#C6A15B]/50 transition-all duration-300"
                data-reveal="fade-up"
              >
                <div className="space-y-3">
                  {/* Rating Stars & Category Badge */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1 text-[#C6A15B]">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          size={15}
                          fill={s <= rev.rating ? '#C6A15B' : 'transparent'}
                          className={s <= rev.rating ? 'text-[#C6A15B]' : 'text-gray-300'}
                        />
                      ))}
                    </div>
                    {rev.stayType && (
                      <span className="text-[10px] uppercase tracking-widest bg-[#FAF7F2] border border-[#C6A15B]/30 text-[#C6A15B] font-semibold px-2.5 py-0.5">
                        {rev.stayType} Stay
                      </span>
                    )}
                  </div>

                  {/* Title */}
                  <h3 className="font-luxury text-xl text-[#171717]">{rev.title}</h3>

                  {/* Message */}
                  <p className="text-xs sm:text-sm text-[#5C554B] leading-relaxed italic">
                    "{rev.message}"
                  </p>
                </div>

                {/* Footer Meta */}
                <div className="pt-4 border-t border-[#C6A15B]/15 flex items-center justify-between text-xs text-[#5C554B]">
                  <div className="flex items-center space-x-2">
                    <div className="w-7 h-7 rounded-full bg-[#FAF7F2] border border-[#C6A15B]/40 flex items-center justify-center text-[#C6A15B] font-bold text-xs uppercase">
                      {rev.name.charAt(0)}
                    </div>
                    <div>
                      <span className="font-semibold text-[#171717] block">{rev.name}</span>
                      <span className="text-[10px] text-emerald-700 font-medium inline-flex items-center space-x-1">
                        <CheckCircle2 size={11} />
                        <span>Verified Public Guest</span>
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] text-gray-400">
                    {new Date(rev.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Bottom CTA Box */}
        <div className="bg-white border border-[#C6A15B]/30 p-8 text-center space-y-4">
          <h3 className="font-luxury text-2xl text-[#171717]">Ready to Experience Hotel SK Grand?</h3>
          <p className="text-xs text-[#5C554B] max-w-lg mx-auto">
            Book your stay directly on Tonk Road, Jaipur for guaranteed best rates, warm hospitality, and modern amenities.
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-2">
            {onOpenBooking && (
              <button
                onClick={onOpenBooking}
                className="bg-[#C6A15B] hover:bg-[#A9823F] text-white text-xs font-semibold py-3 px-8 uppercase tracking-widest transition-all cursor-pointer shadow-sm"
              >
                BOOK YOUR ROOM NOW →
              </button>
            )}
            <button
              onClick={() => setIsModalOpen(true)}
              className="border border-[#C6A15B] text-[#171717] hover:bg-[#C6A15B] hover:text-white text-xs font-semibold py-3 px-6 uppercase tracking-widest transition-all cursor-pointer"
            >
              WRITE A REVIEW
            </button>
          </div>
        </div>
      </div>

      {/* Write a Review Modal */}
      <ReviewModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={refreshReviews}
      />
    </div>
  );
};
